# HideOwnMapMarker v0.1.0

Client-side UE4SS test mod for SCUM.

## Goal

Hide ONLY the local player's own position marker on the world map.

The map itself remains usable.

## Dump evidence

`PrisonerHUD` contains:

    _prisonerMapHUDObject : MapHUDPrisonerObject

`MapHUDPrisonerObject` contains:

    _myPrisonerPositionTexture

and inherits from `MapHUDObject`, which contains:

    _showMarkers : bool

The mod hooks:

    /Script/SCUM.PrisonerHUD:SetHUDMode

and forces:

    _prisonerMapHUDObject._showMarkers = false

## Important

This is a CLIENT mod.

A dedicated-server-only UE4SS mod cannot reliably hide the local player's
own marker because that marker is drawn by the local PrisonerHUD.

Every client on which the marker must be hidden needs this mod/UE4SS.

## Test

1. Install on the game client, not only the dedicated server.
2. Start SCUM through the UE4SS-enabled client.
3. Join the server.
4. Open the map.
5. Check whether your own position marker is gone.
6. Send log lines beginning with:

       [HideOwnMapMarker]

Expected:

    [HideOwnMapMarker] Hook registered: /Script/SCUM.PrisonerHUD:SetHUDMode
    [HideOwnMapMarker] SetHUDMode | Mode=...
    [HideOwnMapMarker] Own map marker disabled | SetHUDMode

## If the marker remains

The next fallback is to null/replace `_myPrisonerPositionTexture` directly,
but v0.1 first tests the cleaner inherited `_showMarkers` flag.
