print("[HideOwnMapMarker] Loading v0.1.0 client test...\n")

local function unwrap(v)
    if v == nil then return nil end
    local ok, r = pcall(function() return v:get() end)
    if ok then return r end
    return v
end

local function safe_valid(obj)
    if obj == nil then return false end
    local ok, valid = pcall(function() return obj:IsValid() end)
    return ok and valid == true
end

local function disable_own_marker(hud, reason)
    hud = unwrap(hud)

    if not safe_valid(hud) then
        print("[HideOwnMapMarker] HUD unavailable | " .. tostring(reason) .. "\n")
        return false
    end

    local ok, err = pcall(function()
        local obj = hud._prisonerMapHUDObject

        -- MapHUDPrisonerObject inherits MapHUDObject, whose reflected
        -- _showMarkers flag controls whether its marker is drawn.
        obj._showMarkers = false

        -- Write the struct back as well, in case this UE4SS build returns
        -- StructProperty values by copy rather than mutable reference.
        hud._prisonerMapHUDObject = obj
    end)

    if ok then
        print("[HideOwnMapMarker] Own map marker disabled | " .. tostring(reason) .. "\n")
        return true
    end

    print("[HideOwnMapMarker] Disable FAILED | " .. tostring(reason) .. " | " .. tostring(err) .. "\n")
    return false
end

local function read_mode(v)
    v = unwrap(v)
    if v == nil then return "nil" end

    local ok, n = pcall(function()
        return v:GetValue()
    end)
    if ok then return tostring(n) end

    return tostring(v)
end

local function register_hook(path, cb)
    local ok, err = pcall(function()
        RegisterHook(path, cb)
    end)

    if ok then
        print("[HideOwnMapMarker] Hook registered: " .. path .. "\n")
    else
        print("[HideOwnMapMarker] Hook FAILED: " .. path .. " | " .. tostring(err) .. "\n")
    end
end

-- EPrisonerHUDMode::Map is dump value 2.
-- We still apply the flag on every mode change so SCUM cannot trivially
-- restore it between map open/close cycles.
register_hook(
    "/Script/SCUM.PrisonerHUD:SetHUDMode",
    function(Context, NewMode)
        print("[HideOwnMapMarker] SetHUDMode | Mode=" .. read_mode(NewMode) .. "\n")
        disable_own_marker(Context, "SetHUDMode")
    end
)

-- Extra initialization opportunity. If this hook is not called on a given
-- build, SetHUDMode remains the primary path.
register_hook(
    "/Script/Engine.HUD:ReceiveDrawHUD",
    function(Context, SizeX, SizeY)
        -- Avoid repeated writes/log spam: only attempt until first success.
        if _G.HideOwnMapMarker_InitDone ~= true then
            if disable_own_marker(Context, "ReceiveDrawHUD init") then
                _G.HideOwnMapMarker_InitDone = true
            end
        end
    end
)

print("[HideOwnMapMarker] Ready.\n")
print("[HideOwnMapMarker] CLIENT-SIDE mod: install on each client that should hide its own map position.\n")
