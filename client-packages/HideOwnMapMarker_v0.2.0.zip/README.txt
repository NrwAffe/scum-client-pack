HideOwnMapMarker v0.2.0 TEST
================================

ZIEL
----
Blendet auf der SCUM-Karte den Marker des eigenen Spielers aus.
Neu in v0.2.0: zusaetzlich wird der direkt benachbarte GradientCircle
(+0x638) ausgeblendet. Dieser ist der aktuelle Kandidat fuer den noch
sichtbaren pulsierenden GPS-Umkreis.

STATUS
------
- +0x630 T_player_marker_smaller: RUNTIME-BESTAETIGT (roter Eigenmarker)
- +0x638 GradientCircle: DUMP-BESTAETIGT / NEUER RUNTIME-TEST
- Kein UE4SS
- Kein PAK notwendig
- Kein sichtbares Helper-Fenster
- Externer Prozess; keine DLL-Injection / keine Hooks
- Schreibt zwei 8-Byte-Pointer im BP_PrisonerHUD_C auf 0

WICHTIG
-------
NUR fuer den aktuellen getesteten SCUM-Build und -nobattleye/private Tests.
Der Helper prueft ImageSize und PE-TimeDateStamp und beendet sich bei einem
anderen Build, statt unbekannte Offsets zu beschreiben.

LAUNCHER
--------
Das Paket ist fuer destination:
  _clientmods\HideOwnMapMarker

Der Launcher startet automatisch:
  START-HIDEOWNMAP.vbs

TEST
----
1. Paket ueber den Launcher installieren.
2. SCUM ueber den Launcher starten (-nobattleye).
3. Charakter spawnen.
4. Karte oeffnen.
5. Pruefen:
   - eigener roter Punkt weg
   - pulsierender Umkreis weg

LOG
---
_clientmods\HideOwnMapMarker\HideOwnMapMarker.log

Wenn der rote Punkt weg ist, aber der Kreis noch pulsiert, bitte genau diesen
Log hochladen. Dann testen wir den naechsten eindeutig zugeordneten HUD-Slot.
