HideOwnMapMarker v0.2.1 BASELINE
================================

Zweck:
Nur den bereits praktisch bestaetigten Pfad 1 wiederherstellen.

Pfad 1:
BP_PrisonerHUD_C + 0x630 -> T_player_marker_smaller

Diese Version aendert KEINEN weiteren Slot.
Insbesondere:
+0x638 GradientCircle wird NICHT angefasst.

Warum:
v0.2.0 machte die HUD-Erkennung faelschlich auch von +0x638 abhaengig.
Dadurch konnte sogar der bewiesene Pfad 1 komplett ausfallen.

TEST:
- ueber Launcher starten
- Karte oeffnen
- eigener roter GPS-Punkt muss verschwinden
- pulsierender Kreis darf in dieser Baseline noch sichtbar bleiben

LOG:
HideOwnMapMarker.log

Erwartete Zeile:
PATCH PATH1 ... oldName='T_player_marker_smaller' ... verify=0x0

Nur -nobattleye/private Testumgebung.
