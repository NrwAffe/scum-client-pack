﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Log = Join-Path $Root "HideOwnMapMarker.log"

function Log([string]$Text) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss.fff"), $Text
    Add-Content -LiteralPath $Log -Value $line -Encoding UTF8
}

@"
============================================================
HideOwnMapMarker v0.2.1 BASELINE
============================================================
ONLY proven path 1:
BP_PrisonerHUD_C + 0x630 -> T_player_marker_smaller

External helper. No injection / no hooks.
NO-BATTLEYE / PRIVATE TEST ONLY.
"@ | Set-Content -LiteralPath $Log -Encoding UTF8

$src = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class HideOwnMapMarker021
{
    const uint PROCESS_VM_OPERATION=0x0008;
    const uint PROCESS_VM_READ=0x0010;
    const uint PROCESS_VM_WRITE=0x0020;
    const uint PROCESS_QUERY_INFORMATION=0x0400;

    const long EXPECTED_IMAGE_SIZE = 0x84BE000;
    const uint EXPECTED_TIMESTAMP = 0x6AA39A87;
    const long FNAME_BLOCKS_RVA = 0x7B52A90;
    const long GUOBJECT_RVA = 0x7B8EFD0;

    const long MARKER_OFFSET = 0x630;

    [DllImport("kernel32.dll", SetLastError=true)]
    static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr h, IntPtr addr, byte[] buffer, IntPtr size, out IntPtr read);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool WriteProcessMemory(IntPtr h, IntPtr addr, byte[] buffer, IntPtr size, out IntPtr written);
    [DllImport("kernel32.dll")]
    static extern bool CloseHandle(IntPtr h);

    static IntPtr H = IntPtr.Zero;
    static long Base;
    static string LogPath;
    static readonly Dictionary<long,long> Originals = new Dictionary<long,long>();

    static void Log(string s) {
        try { File.AppendAllText(LogPath, "["+DateTime.Now.ToString("HH:mm:ss.fff")+"] "+s+Environment.NewLine, Encoding.UTF8); } catch {}
    }

    static bool Read(long addr, byte[] b) {
        IntPtr got;
        return ReadProcessMemory(H, new IntPtr(addr), b, new IntPtr(b.Length), out got) && got.ToInt64()==b.Length;
    }

    static long U64(long a) { var b=new byte[8]; return Read(a,b)?BitConverter.ToInt64(b,0):0; }
    static int I32(long a) { var b=new byte[4]; return Read(a,b)?BitConverter.ToInt32(b,0):0; }
    static ushort U16(long a) { var b=new byte[2]; return Read(a,b)?BitConverter.ToUInt16(b,0):(ushort)0; }

    static bool W64(long a,long v) {
        var b=BitConverter.GetBytes(v);
        IntPtr w;
        bool ok=WriteProcessMemory(H,new IntPtr(a),b,new IntPtr(8),out w) && w.ToInt64()==8;
        Log("WRITE addr=0x"+a.ToString("X")+" value=0x"+v.ToString("X")+" ok="+ok+" err="+Marshal.GetLastWin32Error());
        return ok;
    }

    static string FName(int id) {
        try {
            int block=(int)((uint)id>>16);
            int off=id & 0xFFFF;
            if(block<0 || block>8192) return "";
            long bp=U64(Base+FNAME_BLOCKS_RVA+(block*8L));
            if(bp==0) return "";
            long e=bp+(off*2L);
            ushort hdr=U16(e);
            int len=hdr>>6;
            bool wide=(hdr&1)!=0;
            if(len<=0 || len>512) return "";
            byte[] data=new byte[len*(wide?2:1)];
            if(!Read(e+2,data)) return "";
            return wide?Encoding.Unicode.GetString(data):Encoding.ASCII.GetString(data);
        } catch { return ""; }
    }

    static string ObjName(long obj) {
        if(obj==0) return "";
        return FName(I32(obj+0x18));
    }

    static bool VerifyBuild(Process p) {
        try {
            if(p.MainModule==null) return false;
            Base=p.MainModule.BaseAddress.ToInt64();
            long size=p.MainModule.ModuleMemorySize;
            int pe=I32(Base+0x3C);
            uint ts=(uint)I32(Base+pe+8);
            Log("BUILD base=0x"+Base.ToString("X")+" size=0x"+size.ToString("X")+" timestamp=0x"+ts.ToString("X8"));
            if(size!=EXPECTED_IMAGE_SIZE || ts!=EXPECTED_TIMESTAMP) {
                Log("UNSUPPORTED BUILD");
                return false;
            }
            return true;
        } catch(Exception ex) {
            Log("BUILD ERROR "+ex.Message);
            return false;
        }
    }

    static List<long> FindHudObjects() {
        var result=new List<long>();

        long gu=Base+GUOBJECT_RVA;
        long chunks=U64(gu+0x0);
        int num=I32(gu+0x14);
        int numChunks=I32(gu+0x1C);

        Log("GUOBJECT chunks=0x"+chunks.ToString("X")+" num="+num+" numChunks="+numChunks);

        if(chunks==0 || num<=0 || num>5000000 || numChunks<=0 || numChunks>1024)
            return result;

        const int per=65536;
        const int stride=0x18;
        int remaining=num;

        for(int c=0;c<numChunks && remaining>0;c++) {
            long cp=U64(chunks+c*8L);
            int count=Math.Min(per,remaining);
            remaining-=count;
            if(cp==0) continue;

            byte[] items=new byte[count*stride];
            if(!Read(cp,items)) continue;

            for(int i=0;i<count;i++) {
                long obj=BitConverter.ToInt64(items,i*stride);
                if(obj==0) continue;

                byte[] head=new byte[0x20];
                if(!Read(obj,head)) continue;

                int nameId=BitConverter.ToInt32(head,0x18);
                string n=FName(nameId);

                if(n!="BP_PrisonerHUD_C" && n!="Default__BP_PrisonerHUD_C")
                    continue;

                long marker=U64(obj+MARKER_OFFSET);
                string markerName=ObjName(marker);

                Log("HUD candidate=0x"+obj.ToString("X")+" name="+n+
                    " +630=0x"+marker.ToString("X")+" markerName='"+markerName+"'");

                // Proven path 1 is the ONLY acceptance condition.
                if(markerName=="T_player_marker_smaller")
                    result.Add(obj);
            }
        }

        Log("HUD MATCHES="+result.Count);
        return result;
    }

    static void Patch(long hud) {
        long slot=hud+MARKER_OFFSET;
        long old=U64(slot);

        if(old!=0 && !Originals.ContainsKey(slot))
            Originals[slot]=old;

        if(old==0) {
            Log("PATCH already zero hud=0x"+hud.ToString("X")+" slot=0x"+slot.ToString("X"));
            return;
        }

        string oldName=ObjName(old);
        if(oldName!="T_player_marker_smaller") {
            Log("PATCH REFUSED unexpected object '"+oldName+"' hud=0x"+hud.ToString("X"));
            return;
        }

        bool ok=W64(slot,0);
        long verify=U64(slot);
        Log("PATCH PATH1 hud=0x"+hud.ToString("X")+
            " slot(+630)=0x"+slot.ToString("X")+
            " old=0x"+old.ToString("X")+
            " oldName='"+oldName+"'"+
            " ok="+ok+
            " verify=0x"+verify.ToString("X"));
    }

    static void Restore() {
        foreach(var kv in Originals) {
            try {
                long cur=U64(kv.Key);
                if(cur==0) {
                    bool ok=W64(kv.Key,kv.Value);
                    Log("RESTORE addr=0x"+kv.Key.ToString("X")+" ok="+ok);
                }
            } catch {}
        }
    }

    public static void Run(string logPath) {
        LogPath=logPath;
        Log("WAITING for SCUM.exe");

        Process p=null;
        while(p==null) {
            var ps=Process.GetProcessesByName("SCUM");
            if(ps.Length>0) p=ps[0];
            else Thread.Sleep(500);
        }

        Log("SCUM found PID="+p.Id);

        H=OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ|PROCESS_VM_WRITE|PROCESS_VM_OPERATION,false,p.Id);
        if(H==IntPtr.Zero) {
            Log("OpenProcess failed err="+Marshal.GetLastWin32Error());
            return;
        }

        try {
            if(!VerifyBuild(p)) return;

            var patched=new HashSet<long>();

            while(!p.HasExited) {
                if(patched.Count==0) {
                    var list=FindHudObjects();
                    foreach(long hud in list) {
                        Patch(hud);
                        patched.Add(hud);
                    }
                    if(list.Count==0)
                        Log("HUD not ready; retrying");
                } else {
                    var dead=new List<long>();

                    foreach(long hud in patched) {
                        string hudName=ObjName(hud);
                        if(hudName!="BP_PrisonerHUD_C" && hudName!="Default__BP_PrisonerHUD_C") {
                            dead.Add(hud);
                            continue;
                        }

                        long cur=U64(hud+MARKER_OFFSET);
                        if(cur!=0) Patch(hud);
                    }

                    foreach(long d in dead) patched.Remove(d);
                }

                Thread.Sleep(patched.Count>0 ? 1000 : 2500);
            }

            Log("SCUM exited");
        }
        catch(Exception ex) {
            Log("FATAL "+ex);
        }
        finally {
            try {
                if(p!=null && !p.HasExited) Restore();
            } catch {}

            if(H!=IntPtr.Zero) CloseHandle(H);
        }
    }
}
'@

try {
    Add-Type -TypeDefinition $src -Language CSharp
    Log "Helper starting"
    [HideOwnMapMarker021]::Run($Log)
}
catch {
    Log ("POWERSHELL ERROR: " + $_.Exception.ToString())
}
