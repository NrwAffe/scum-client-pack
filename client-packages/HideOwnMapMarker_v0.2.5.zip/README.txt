HideOwnMapMarker v0.2.5 PULSE TEST
=================================

Bestaetigt:
  BP_PrisonerHUD_C + 0x638 -> T_player_marker_smaller
  -> roter eigener GPS-Marker wird entfernt.

Neuer Test:
  BP_PrisonerHUD_C + 0x640 -> erwartetes Objekt GradientCircle

WICHTIG:
+0x640 wird NICHT blind beschrieben.
Der Helper liest den Pointer zuerst und prueft:
  Name  = GradientCircle
  Class = Texture2D

Nur wenn beides stimmt, wird auch +0x640 auf 0 gesetzt.

Erwarteter Log bei Treffer:
  PULSE CANDIDATE ... name='GradientCircle' class='Texture2D'
  PATCH PULSE ... verify=0x0
  RESULT markerHidden=True pulsePatched=True

Wenn dort ein anderes Objekt liegt:
  PULSE REFUSED ...
Dann bleibt der Pulse-Slot unveraendert.

Test:
1. v0.2.5 ueber den Launcher installieren.
2. Nur ueber den Launcher starten; nichts manuell ausfuehren.
3. Einloggen/spawnen.
4. Warten bis der Marker-Patch durch ist.
5. Karte oeffnen.
6. Pruefen:
   - roter eigener Marker weg
   - pulsierender Kreis weg oder weiterhin sichtbar
7. HideOwnMapMarker.log hochladen.

Nur -nobattleye / private Testumgebung.
