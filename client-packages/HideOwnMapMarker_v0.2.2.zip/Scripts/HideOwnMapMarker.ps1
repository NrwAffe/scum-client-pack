﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Log = Join-Path $Root "HideOwnMapMarker.log"

@"
============================================================
HideOwnMapMarker v0.2.2 DYNAMIC
============================================================
Proven path 1 only:
BP_PrisonerHUD_C + 0x630 -> T_player_marker_smaller

Dynamic discovery for current SCUM builds.
No fixed FName/GUObject RVA required.
External helper. No injection / no hooks.
NO-BATTLEYE / PRIVATE TEST ONLY.
"@ | Set-Content -LiteralPath $Log -Encoding UTF8

$src = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class HideOwnMapMarker022
{
    const uint PROCESS_VM_OPERATION=0x0008;
    const uint PROCESS_VM_READ=0x0010;
    const uint PROCESS_VM_WRITE=0x0020;
    const uint PROCESS_QUERY_INFORMATION=0x0400;

    const uint MEM_COMMIT=0x1000;
    const uint MEM_PRIVATE=0x20000;
    const uint MEM_IMAGE=0x1000000;

    const uint PAGE_NOACCESS=0x01;
    const uint PAGE_GUARD=0x100;

    const long MARKER_OFFSET=0x630;

    [StructLayout(LayoutKind.Sequential)]
    struct MEMORY_BASIC_INFORMATION {
        public IntPtr BaseAddress;
        public IntPtr AllocationBase;
        public uint AllocationProtect;
        public UIntPtr RegionSize;
        public uint State;
        public uint Protect;
        public uint Type;
    }

    [DllImport("kernel32.dll", SetLastError=true)]
    static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr h, IntPtr addr, byte[] buffer, IntPtr size, out IntPtr read);

    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool WriteProcessMemory(IntPtr h, IntPtr addr, byte[] buffer, IntPtr size, out IntPtr written);

    [DllImport("kernel32.dll")]
    static extern IntPtr VirtualQueryEx(IntPtr h, IntPtr addr, out MEMORY_BASIC_INFORMATION mbi, IntPtr len);

    [DllImport("kernel32.dll")]
    static extern bool CloseHandle(IntPtr h);

    class Region {
        public long Base, Size;
        public uint Type, Protect;
    }

    static IntPtr H=IntPtr.Zero;
    static long ImageBase, ImageEnd;
    static string LogPath;

    static long FNameTable=0;
    static int FNameBlockCount=0;
    static long MarkerTexture=0;

    static readonly Dictionary<long,long> Originals=new Dictionary<long,long>();

    static void Log(string s) {
        try {
            File.AppendAllText(LogPath, "["+DateTime.Now.ToString("HH:mm:ss.fff")+"] "+s+Environment.NewLine, Encoding.UTF8);
        } catch {}
    }

    static bool IsReadable(uint protect) {
        if((protect & PAGE_GUARD)!=0) return false;
        if((protect & PAGE_NOACCESS)!=0) return false;
        return true;
    }

    static List<Region> Regions() {
        var list=new List<Region>();
        long addr=0;
        int mbiSize=Marshal.SizeOf(typeof(MEMORY_BASIC_INFORMATION));

        while(addr < 0x00007FFFFFFF0000L) {
            MEMORY_BASIC_INFORMATION mbi;
            IntPtr r=VirtualQueryEx(H,new IntPtr(addr),out mbi,new IntPtr(mbiSize));
            if(r==IntPtr.Zero) break;

            long b=mbi.BaseAddress.ToInt64();
            long sz=(long)mbi.RegionSize.ToUInt64();
            if(sz<=0) break;

            if(mbi.State==MEM_COMMIT && IsReadable(mbi.Protect))
                list.Add(new Region{Base=b,Size=sz,Type=mbi.Type,Protect=mbi.Protect});

            long next=b+sz;
            if(next<=addr) break;
            addr=next;
        }
        return list;
    }

    static bool Read(long addr, byte[] b) {
        IntPtr got;
        return ReadProcessMemory(H,new IntPtr(addr),b,new IntPtr(b.Length),out got) && got.ToInt64()==b.Length;
    }

    static long U64(long a) {
        byte[] b=new byte[8];
        return Read(a,b)?BitConverter.ToInt64(b,0):0;
    }

    static int I32(long a) {
        byte[] b=new byte[4];
        return Read(a,b)?BitConverter.ToInt32(b,0):0;
    }

    static ushort U16(long a) {
        byte[] b=new byte[2];
        return Read(a,b)?BitConverter.ToUInt16(b,0):(ushort)0;
    }

    static bool W64(long a,long v) {
        byte[] b=BitConverter.GetBytes(v);
        IntPtr wrote;
        bool ok=WriteProcessMemory(H,new IntPtr(a),b,new IntPtr(8),out wrote) && wrote.ToInt64()==8;
        Log("WRITE addr=0x"+a.ToString("X")+" value=0x"+v.ToString("X")+" ok="+ok+" err="+Marshal.GetLastWin32Error());
        return ok;
    }

    static IEnumerable<long> FindBytesInRegion(Region r, byte[] needle) {
        const int CHUNK=4*1024*1024;
        int overlap=Math.Max(0,needle.Length-1);
        long pos=0;
        byte[] carry=new byte[0];

        while(pos<r.Size) {
            int want=(int)Math.Min(CHUNK,r.Size-pos);
            byte[] buf=new byte[carry.Length+want];
            if(carry.Length>0) Buffer.BlockCopy(carry,0,buf,0,carry.Length);

            byte[] part=new byte[want];
            if(!Read(r.Base+pos,part)) {
                pos+=want;
                carry=new byte[0];
                continue;
            }
            Buffer.BlockCopy(part,0,buf,carry.Length,want);

            for(int i=0;i<=buf.Length-needle.Length;i++) {
                bool match=true;
                for(int j=0;j<needle.Length;j++) {
                    if(buf[i+j]!=needle[j]) { match=false; break; }
                }
                if(match) {
                    long absolute=r.Base+pos-carry.Length+i;
                    if(absolute>=r.Base && absolute<r.Base+r.Size)
                        yield return absolute;
                }
            }

            if(overlap>0) {
                int keep=Math.Min(overlap,buf.Length);
                carry=new byte[keep];
                Buffer.BlockCopy(buf,buf.Length-keep,carry,0,keep);
            }
            pos+=want;
        }
    }

    static Region FindRegion(List<Region> rs,long addr) {
        foreach(var r in rs)
            if(addr>=r.Base && addr<r.Base+r.Size) return r;
        return null;
    }

    static bool PlausiblePtr(long p,List<Region> rs) {
        if(p<0x10000 || p>0x00007FFFFFFFFFFFL) return false;
        return FindRegion(rs,p)!=null;
    }

    static long FindFNameEntry(List<Region> rs,string text) {
        byte[] needle=Encoding.ASCII.GetBytes(text);
        foreach(var r in rs) {
            // FName pools are normally private committed memory. Restrict first pass.
            if(r.Type!=MEM_PRIVATE) continue;
            foreach(long textAddr in FindBytesInRegion(r,needle)) {
                long entry=textAddr-2;
                ushort hdr=U16(entry);
                int len=hdr>>6;
                bool wide=(hdr&1)!=0;
                if(!wide && len==text.Length) {
                    Log("FNAME ENTRY text='"+text+"' entry=0x"+entry.ToString("X")+" region=0x"+r.Base.ToString("X")+" hdr=0x"+hdr.ToString("X4"));
                    return entry;
                }
            }
        }
        return 0;
    }

    static long FindPointerInImage(long value) {
        byte[] needle=BitConverter.GetBytes(value);
        long size=ImageEnd-ImageBase;
        var r=new Region{Base=ImageBase,Size=size,Type=MEM_IMAGE,Protect=0};
        foreach(long hit in FindBytesInRegion(r,needle)) return hit;
        return 0;
    }

    static bool IsLikelyFNameBlockPtr(long p,List<Region> rs) {
        Region r=FindRegion(rs,p);
        if(r==null || r.Type!=MEM_PRIVATE) return false;
        // FName blocks seen in this build family are 64K-ish aligned or within a private pool area.
        return true;
    }

    static bool BuildFNameTable(List<Region> rs,long entry) {
        Region er=FindRegion(rs,entry);
        if(er==null) return false;

        // Previous runtime probes prove the FName block pointer points at the containing private block.
        // Try several aligned bases because VirtualQuery can split one pool block into subregions.
        long[] bases=new long[] {
            er.Base,
            entry & ~0xFFFL,
            entry & ~0xFFFFL
        };

        foreach(long blockBase in bases) {
            long slot=FindPointerInImage(blockBase);
            if(slot==0) continue;

            // Walk backward/forward over contiguous readable private pointers.
            long start=slot;
            for(int i=0;i<4096;i++) {
                long prev=start-8;
                if(prev<ImageBase) break;
                long p=U64(prev);
                if(!IsLikelyFNameBlockPtr(p,rs)) break;
                start=prev;
            }

            int count=0;
            for(int i=0;i<8192;i++) {
                long p=U64(start+i*8L);
                if(!IsLikelyFNameBlockPtr(p,rs)) break;
                count++;
            }

            if(count<2) continue;

            long idx=(slot-start)/8;
            long offsetBytes=entry-blockBase;
            if(idx<0 || idx>=count || offsetBytes<0 || offsetBytes>0x1FFFF) continue;

            int id=((int)idx<<16) | ((int)(offsetBytes/2)&0xFFFF);

            FNameTable=start;
            FNameBlockCount=count;

            string decoded=FName(id);
            Log("FNAME TABLE start=0x"+start.ToString("X")+" count="+count+" anchorIndex="+idx+
                " blockBase=0x"+blockBase.ToString("X")+" derivedId=0x"+id.ToString("X")+" decode='"+decoded+"'");

            if(decoded=="T_player_marker_smaller") return true;

            FNameTable=0;
            FNameBlockCount=0;
        }
        return false;
    }

    static string FName(int id) {
        if(FNameTable==0) return "";
        try {
            int block=(int)((uint)id>>16);
            int off=id&0xFFFF;
            if(block<0 || block>=FNameBlockCount) return "";
            long bp=U64(FNameTable+block*8L);
            if(bp==0) return "";
            long e=bp+off*2L;
            ushort hdr=U16(e);
            int len=hdr>>6;
            bool wide=(hdr&1)!=0;
            if(len<=0 || len>512) return "";
            byte[] data=new byte[len*(wide?2:1)];
            if(!Read(e+2,data)) return "";
            return wide?Encoding.Unicode.GetString(data):Encoding.ASCII.GetString(data);
        } catch { return ""; }
    }

    static string ObjName(long obj) {
        if(obj==0) return "";
        return FName(I32(obj+0x18));
    }

    static string ClassName(long obj) {
        if(obj==0) return "";
        long cls=U64(obj+0x10);
        return ObjName(cls);
    }

    static int FindNameIdForEntry(long entry,List<Region> rs) {
        Region er=FindRegion(rs,entry);
        if(er==null || FNameTable==0) return -1;

        for(int block=0;block<FNameBlockCount;block++) {
            long bp=U64(FNameTable+block*8L);
            if(bp==0) continue;
            long delta=entry-bp;
            if(delta>=0 && delta<0x20000 && (delta%2)==0) {
                int id=(block<<16)|((int)(delta/2)&0xFFFF);
                if(FName(id)=="T_player_marker_smaller") return id;
            }
        }
        return -1;
    }

    static long FindMarkerTexture(List<Region> rs,int markerNameId) {
        byte[] idBytes=BitConverter.GetBytes(markerNameId);

        foreach(var r in rs) {
            if(r.Type!=MEM_PRIVATE) continue;
            foreach(long hit in FindBytesInRegion(r,idBytes)) {
                long obj=hit-0x18;
                if(obj<r.Base) continue;

                long vt=U64(obj);
                if(vt<ImageBase || vt>=ImageEnd) continue;

                string n=ObjName(obj);
                if(n!="T_player_marker_smaller") continue;

                string cls=ClassName(obj);
                Log("MARKER UObject=0x"+obj.ToString("X")+" name='"+n+"' class='"+cls+"'");
                if(cls=="Texture2D") return obj;
            }
        }
        return 0;
    }

    static long FindHudSlot(List<Region> rs,long markerObj) {
        byte[] ptr=BitConverter.GetBytes(markerObj);

        foreach(var r in rs) {
            if(r.Type!=MEM_PRIVATE) continue;
            foreach(long slot in FindBytesInRegion(r,ptr)) {
                long hud=slot-MARKER_OFFSET;
                if(hud<=0) continue;

                long vt=U64(hud);
                if(vt<ImageBase || vt>=ImageEnd) continue;

                string cn=ClassName(hud);
                string on=ObjName(hud);

                if(cn=="BP_PrisonerHUD_C") {
                    Log("HUD MATCH hud=0x"+hud.ToString("X")+" objName='"+on+"' class='"+cn+
                        "' slot=0x"+slot.ToString("X")+" current=0x"+U64(slot).ToString("X"));
                    return slot;
                }
            }
        }
        return 0;
    }

    static bool DiscoverAndPatch(Process p) {
        var rs=Regions();
        Log("REGIONS readable="+rs.Count);

        long entry=FindFNameEntry(rs,"T_player_marker_smaller");
        if(entry==0) {
            Log("DISCOVERY FAIL: FName entry not found");
            return false;
        }

        if(!BuildFNameTable(rs,entry)) {
            Log("DISCOVERY FAIL: FName table not resolved");
            return false;
        }

        int markerId=FindNameIdForEntry(entry,rs);
        if(markerId<0) {
            Log("DISCOVERY FAIL: marker FNameId not resolved");
            return false;
        }
        Log("MARKER FNameId=0x"+markerId.ToString("X"));

        MarkerTexture=FindMarkerTexture(rs,markerId);
        if(MarkerTexture==0) {
            Log("DISCOVERY FAIL: marker Texture2D UObject not found");
            return false;
        }

        long slot=FindHudSlot(rs,MarkerTexture);
        if(slot==0) {
            Log("DISCOVERY FAIL: BP_PrisonerHUD_C +0x630 backref not found (HUD may not be spawned yet)");
            return false;
        }

        if(!Originals.ContainsKey(slot))
            Originals[slot]=MarkerTexture;

        bool ok=W64(slot,0);
        long verify=U64(slot);

        Log("PATCH PATH1 slot(+630)=0x"+slot.ToString("X")+
            " old=0x"+MarkerTexture.ToString("X")+
            " ok="+ok+" verify=0x"+verify.ToString("X"));

        return ok && verify==0;
    }

    static void Restore() {
        foreach(var kv in Originals) {
            try {
                if(U64(kv.Key)==0) {
                    bool ok=W64(kv.Key,kv.Value);
                    Log("RESTORE addr=0x"+kv.Key.ToString("X")+" ok="+ok);
                }
            } catch {}
        }
    }

    public static void Run(string logPath) {
        LogPath=logPath;
        Log("WAITING for SCUM.exe");

        Process p=null;
        while(p==null) {
            Process[] ps=Process.GetProcessesByName("SCUM");
            if(ps.Length>0) p=ps[0];
            else Thread.Sleep(500);
        }

        Log("SCUM found PID="+p.Id);

        H=OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ|PROCESS_VM_WRITE|PROCESS_VM_OPERATION,false,p.Id);
        if(H==IntPtr.Zero) {
            Log("OpenProcess failed err="+Marshal.GetLastWin32Error());
            return;
        }

        try {
            ImageBase=p.MainModule.BaseAddress.ToInt64();
            ImageEnd=ImageBase+p.MainModule.ModuleMemorySize;

            int pe=I32(ImageBase+0x3C);
            uint ts=(uint)I32(ImageBase+pe+8);

            Log("BUILD base=0x"+ImageBase.ToString("X")+
                " size=0x"+p.MainModule.ModuleMemorySize.ToString("X")+
                " timestamp=0x"+ts.ToString("X8"));

            bool patched=false;
            int attempts=0;

            while(!p.HasExited && !patched) {
                attempts++;
                Log("DISCOVERY attempt="+attempts);
                patched=DiscoverAndPatch(p);
                if(!patched) {
                    // Reset dynamic state before retry after spawn/load.
                    FNameTable=0;
                    FNameBlockCount=0;
                    MarkerTexture=0;
                    Thread.Sleep(5000);
                }
            }

            if(patched) {
                Log("SUCCESS: proven path 1 hidden");
                while(!p.HasExited) Thread.Sleep(1000);
            }
        }
        catch(Exception ex) {
            Log("FATAL "+ex);
        }
        finally {
            try {
                if(p!=null && !p.HasExited) Restore();
            } catch {}
            if(H!=IntPtr.Zero) CloseHandle(H);
        }
    }
}
'@

try {
    Add-Type -TypeDefinition $src -Language CSharp
    [HideOwnMapMarker022]::Run($Log)
}
catch {
    Add-Content -LiteralPath $Log -Value ("["+$(Get-Date -Format "HH:mm:ss.fff")+"] POWERSHELL ERROR "+$_.Exception.ToString()) -Encoding UTF8
}
