HideOwnMapMarker v0.2.2 DYNAMIC
================================

Nur bewiesener Pfad 1:
BP_PrisonerHUD_C + 0x630 -> T_player_marker_smaller

Aenderung gegenueber v0.2.1:
- kein alter Build-Fingerprint erforderlich
- kein festes FNamePool-RVA
- kein festes GUObjectArray-RVA
- dynamische Suche nach FName, Texture2D und BP_PrisonerHUD_C-Backref

Diese Version testet NOCH NICHT den pulsierenden Kreis.
Zuerst muss der rote Eigenmarker auf dem aktuellen SCUM-Build wieder sicher verschwinden.

Erwartetes Log bei Erfolg:
FNAME ENTRY ...
FNAME TABLE ...
MARKER UObject=...
HUD MATCH ...
PATCH PATH1 ... verify=0x0
SUCCESS: proven path 1 hidden

Bei Fehlschlag bitte HideOwnMapMarker.log hochladen.

Nur -nobattleye / private Testumgebung.
