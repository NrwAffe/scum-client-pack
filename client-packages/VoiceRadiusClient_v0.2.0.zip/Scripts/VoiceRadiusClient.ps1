﻿param(
    [switch]$Debug
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigFile = Join-Path $Root "Config\config.json"
$LogFile = Join-Path $Root "VoiceRadiusClient.log"

function Log([string]$m) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $m
    Add-Content -LiteralPath $LogFile -Value $line
    if($Debug){ Write-Host $line }
}

$config = Get-Content -LiteralPath $ConfigFile -Raw | ConvertFrom-Json

$src = @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public static class VoiceRadiusKeys
{
    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    public const int WH_KEYBOARD_LL = 13;
    public const int WM_KEYDOWN = 0x0100;
    public const int WM_SYSKEYDOWN = 0x0104;

    [StructLayout(LayoutKind.Sequential)]
    public struct KBDLLHOOKSTRUCT
    {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [DllImport("user32.dll")]
    public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll")]
    public static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    public static bool IsScumForeground()
    {
        IntPtr hwnd = GetForegroundWindow();
        if(hwnd == IntPtr.Zero) return false;

        uint pid;
        GetWindowThreadProcessId(hwnd, out pid);

        try
        {
            Process p = Process.GetProcessById((int)pid);
            return String.Equals(p.ProcessName, "SCUM", StringComparison.OrdinalIgnoreCase);
        }
        catch { return false; }
    }
}
'@

Add-Type -TypeDefinition $src -Language CSharp

$win32 = @'
using System;
using System.Runtime.InteropServices;
public static class VRWindow {
    [DllImport("user32.dll")]
    public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll")]
    public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
}
'@
Add-Type -TypeDefinition $win32 -Language CSharp

$script:modes = @("whisper","normal","shout")
$script:mode = [string]$config.defaultMode
if($script:modes -notcontains $script:mode.ToLowerInvariant()) { $script:mode = "normal" }
$script:sendingCommand = $false
$script:lastToggle = [DateTime]::MinValue

function Get-ModeInfo([string]$mode) {
    switch($mode.ToLowerInvariant()) {
        "whisper" {
            return [pscustomobject]@{
                Label = "WHISPER"
                Meters = [int]$config.radiiMeters.whisper
                Diameter = [int]$config.ringPixels.whisper
                Command = [string]$config.commands.whisper
            }
        }
        "shout" {
            return [pscustomobject]@{
                Label = "SHOUT"
                Meters = [int]$config.radiiMeters.shout
                Diameter = [int]$config.ringPixels.shout
                Command = [string]$config.commands.shout
            }
        }
        default {
            return [pscustomobject]@{
                Label = "NORMAL"
                Meters = [int]$config.radiiMeters.normal
                Diameter = [int]$config.ringPixels.normal
                Command = [string]$config.commands.normal
            }
        }
    }
}

function Send-ServerCommand([string]$command) {
    if([string]::IsNullOrWhiteSpace($command)) { return }
    if(-not [VoiceRadiusKeys]::IsScumForeground()) {
        Log "Serverbefehl nicht gesendet: SCUM ist nicht im Vordergrund."
        return
    }

    try {
        $script:sendingCommand = $true

        [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
        Start-Sleep -Milliseconds ([int]$config.chat.openDelayMs)

        $escaped = $command.Replace("{","{{}").Replace("}","{}}").Replace("+","{+}").Replace("^","{^}").Replace("%","{%}").Replace("~","{~}").Replace("(","{(}").Replace(")","{)}").Replace("[","{[}").Replace("]","{]}")

        [System.Windows.Forms.SendKeys]::SendWait($escaped)
        Start-Sleep -Milliseconds ([int]$config.chat.typeDelayMs)
        [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")

        Log "Serverbefehl gesendet: $command"
    }
    catch {
        Log "FEHLER beim Senden von '$command': $($_.Exception.Message)"
    }
    finally {
        Start-Sleep -Milliseconds 120
        $script:sendingCommand = $false
    }
}

function Set-Mode([string]$newMode, [bool]$sendCommand = $true) {
    $newMode = $newMode.ToLowerInvariant()
    if($script:modes -notcontains $newMode) { return }

    $script:mode = $newMode
    $info = Get-ModeInfo $newMode
    Log "MODE -> $($info.Label) / $($info.Meters)m"

    $form.Invalidate()

    if($sendCommand -and $config.sendServerCommand -eq $true) {
        Send-ServerCommand $info.Command
    }
}

function Next-Mode {
    $current = [Array]::IndexOf($script:modes, $script:mode.ToLowerInvariant())
    if($current -lt 0) { $current = 1 }
    $next = ($current + 1) % $script:modes.Count
    Set-Mode $script:modes[$next] $true
}

$form = New-Object System.Windows.Forms.Form
$form.FormBorderStyle = "None"
$form.ShowInTaskbar = $false
$form.TopMost = $true
$form.BackColor = [Drawing.Color]::Magenta
$form.TransparencyKey = [Drawing.Color]::Magenta
$form.StartPosition = "Manual"
$form.Width = 460
$form.Height = 460

$screen = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Left = [Math]::Max(0, $screen.Right - $form.Width - [int]$config.marginRight)
$form.Top  = [Math]::Max(0, $screen.Bottom - $form.Height - [int]$config.marginBottom)

$WS_EX_LAYERED = 0x00080000
$WS_EX_TRANSPARENT = 0x00000020
$WS_EX_TOOLWINDOW = 0x00000080
$GWL_EXSTYLE = -20

$form.Add_Shown({
    $style = [VRWindow]::GetWindowLong($form.Handle, $GWL_EXSTYLE)
    [VRWindow]::SetWindowLong(
        $form.Handle,
        $GWL_EXSTYLE,
        $style -bor $WS_EX_LAYERED -bor $WS_EX_TRANSPARENT -bor $WS_EX_TOOLWINDOW
    ) | Out-Null
})

$form.Add_Paint({
    param($sender,$e)

    $info = Get-ModeInfo $script:mode
    $g = $e.Graphics
    $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias

    $cx = [int]($form.ClientSize.Width / 2)
    $cy = [int]($form.ClientSize.Height / 2)
    $d = [int]$info.Diameter
    $x = $cx - [int]($d/2)
    $y = $cy - [int]($d/2)

    $pen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(230,255,255,255), 4)
    $pen.DashStyle = [Drawing.Drawing2D.DashStyle]::Dash
    $g.DrawEllipse($pen,$x,$y,$d,$d)
    $pen.Dispose()

    $centerPen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(240,255,255,255), 2)
    $g.DrawLine($centerPen,$cx-8,$cy,$cx+8,$cy)
    $g.DrawLine($centerPen,$cx,$cy-8,$cx,$cy+8)
    $centerPen.Dispose()

    $fill = New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(150,0,0,0))
    $box = New-Object Drawing.RectangleF(86,184,288,92)
    $g.FillRectangle($fill,$box)
    $fill.Dispose()

    $font1 = New-Object Drawing.Font("Segoe UI",19,[Drawing.FontStyle]::Bold)
    $font2 = New-Object Drawing.Font("Segoe UI",10,[Drawing.FontStyle]::Regular)
    $brush = New-Object Drawing.SolidBrush([Drawing.Color]::White)

    $text1 = "{0}  |  {1} m" -f $info.Label,$info.Meters
    $sz = $g.MeasureString($text1,$font1)
    $g.DrawString($text1,$font1,$brush,$cx-$sz.Width/2,192)

    $text2 = "^ = Reichweite wechseln"
    $sz2 = $g.MeasureString($text2,$font2)
    $g.DrawString($text2,$font2,$brush,$cx-$sz2.Width/2,237)

    $brush.Dispose()
    $font1.Dispose()
    $font2.Dispose()
})

$proc = [VoiceRadiusKeys+LowLevelKeyboardProc]{
    param($nCode,$wParam,$lParam)

    if(
        $nCode -ge 0 -and
        -not $script:sendingCommand -and
        (($wParam.ToInt32() -eq [VoiceRadiusKeys]::WM_KEYDOWN) -or
         ($wParam.ToInt32() -eq [VoiceRadiusKeys]::WM_SYSKEYDOWN))
    ) {
        if([VoiceRadiusKeys]::IsScumForeground()) {
            $data = [Runtime.InteropServices.Marshal]::PtrToStructure(
                $lParam,
                [type][VoiceRadiusKeys+KBDLLHOOKSTRUCT]
            )

            $vk = [int]$data.vkCode
            $isCycleKey = ($vk -eq [int]$config.cycleKeyVk) -or (
                $config.fallbackF9 -eq $true -and
                $vk -eq [int][System.Windows.Forms.Keys]::F9
            )

            if($isCycleKey) {
                $now = Get-Date
                if(($now - $script:lastToggle).TotalMilliseconds -ge [int]$config.debounceMs) {
                    $script:lastToggle = $now
                    Next-Mode
                }
            }
        }
    }

    return [VoiceRadiusKeys]::CallNextHookEx([IntPtr]::Zero,$nCode,$wParam,$lParam)
}

$module = [Diagnostics.Process]::GetCurrentProcess().MainModule
$hMod = [VoiceRadiusKeys]::GetModuleHandle($module.ModuleName)
$hook = [VoiceRadiusKeys]::SetWindowsHookEx([VoiceRadiusKeys]::WH_KEYBOARD_LL,$proc,$hMod,0)

if($hook -eq [IntPtr]::Zero) {
    throw "Keyboard hook konnte nicht gesetzt werden."
}

Log "VoiceRadiusClient v0.2.0 gestartet."
Log "^ wechselt: Whisper 3m -> Normal 15m -> Shout 40m -> ..."
Log "Fallback-Taste: F9"
Log ("Startmodus: " + (Get-ModeInfo $script:mode).Label)

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1000
$timer.Add_Tick({
    $scum = Get-Process -Name SCUM -ErrorAction SilentlyContinue | Select-Object -First 1

    if($scum) {
        if(-not $form.Visible) { $form.Show() }
    } else {
        if($config.exitWhenScumCloses -eq $true) {
            $timer.Stop()
            $form.Close()
        }
    }
})
$timer.Start()

try {
    [void]$form.ShowDialog()
}
finally {
    if($hook -ne [IntPtr]::Zero) {
        [VoiceRadiusKeys]::UnhookWindowsHookEx($hook) | Out-Null
    }
}
