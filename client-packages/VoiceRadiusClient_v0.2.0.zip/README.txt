VoiceRadiusClient v0.2.0
=========================

^ wechselt direkt:
Whisper 3 m -> Normal 15 m -> Shout 40 m -> Whisper 3 m ...

Dabei wird automatisch:
- die visuelle Anzeige aktualisiert
- der Ring angepasst
- !vw / !vn / !vs ueber den SCUM-Chat gesendet

Fallback:
F9 = ebenfalls Reichweite wechseln

Hinweis:
Der Ring ist aktuell ein HUD-Indikator und noch kein geometrisch
exakter 3/15/40-m-Kreis auf dem Boden der Spielwelt.

Keine DLL-Injection, kein UE4SS, keine SCUM-Speicherwrites.
