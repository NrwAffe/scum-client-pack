﻿$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$ConfigPath = Join-Path $Root "Config\config.json"
$BotLog = Join-Path $Root "AdminBot.log"

function Log([string]$s) {
    Add-Content -LiteralPath $BotLog -Value ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss.fff"), $s) -Encoding UTF8
}

function Get-ScumLogPath {
    $p = Join-Path $env:LOCALAPPDATA "SCUM\Saved\Logs\SCUM.log"
    if(Test-Path -LiteralPath $p) { return $p }
    return $null
}

function Get-ScumProcess {
    return (Get-Process -Name SCUM -ErrorAction SilentlyContinue | Select-Object -First 1)
}

function Send-ScumCommand([System.Diagnostics.Process]$Process, [string]$Command) {
    $ws = New-Object -ComObject WScript.Shell

    if(-not $ws.AppActivate($Process.Id)) {
        Log "COMMAND FAIL: SCUM window could not be activated PID=$($Process.Id)"
        return $false
    }

    Start-Sleep -Milliseconds 300

    # Force a known UI state first: close an already-open chat/menu input.
    $ws.SendKeys("{ESC}")
    Log "INPUT STATE: pre-command ESC"
    Start-Sleep -Milliseconds 350

    # Open chat/command input.
    $ws.SendKeys("t")
    Log "INPUT STATE: chat open key T"
    Start-Sleep -Milliseconds 450

    foreach($ch in $Command.ToCharArray()) {
        switch($ch) {
            "+" { $ws.SendKeys("{+}") }
            "^" { $ws.SendKeys("{^}") }
            "%" { $ws.SendKeys("{%}") }
            "~" { $ws.SendKeys("{~}") }
            "(" { $ws.SendKeys("{(}") }
            ")" { $ws.SendKeys("{)}") }
            "{" { $ws.SendKeys("{{}") }
            "}" { $ws.SendKeys("{}}") }
            default { $ws.SendKeys([string]$ch) }
        }
        Start-Sleep -Milliseconds 10
    }

    Log "INPUT STATE: command typed"
    Start-Sleep -Milliseconds 200

    $ws.SendKeys("{ENTER}")
    Log "COMMAND SENT: $Command"
    Start-Sleep -Milliseconds 500

    # SCUM may keep chat/input focused after command execution.
    # Force it closed so the next probe cannot append "t" to the previous field.
    $ws.SendKeys("{ESC}")
    Log "INPUT STATE: post-command ESC"
    Start-Sleep -Milliseconds 250

    return $true
}

function Read-NewLogBytes([string]$Path, [long]$StartOffset) {
    if(-not (Test-Path -LiteralPath $Path)) { return "" }

    $fs = [System.IO.File]::Open($Path,
        [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read,
        [System.IO.FileShare]::ReadWrite)

    try {
        if($StartOffset -gt $fs.Length) { $StartOffset = 0 }
        $null = $fs.Seek($StartOffset, [System.IO.SeekOrigin]::Begin)
        $remaining = $fs.Length - $StartOffset
        if($remaining -le 0) { return "" }

        $buf = New-Object byte[] $remaining
        $read = $fs.Read($buf,0,$buf.Length)
        return [Text.Encoding]::UTF8.GetString($buf,0,$read)
    }
    finally {
        $fs.Dispose()
    }
}

function Get-SteamIdsFromText([string]$Text) {
    if([string]::IsNullOrWhiteSpace($Text)) { return @() }

    return @(
        [regex]::Matches($Text, '(?<!\d)7656119\d{10}(?!\d)') |
        ForEach-Object { $_.Value } |
        Sort-Object -Unique
    )
}

function Classify-Capture([string]$Text) {
    $result = [ordered]@{
        ownChatEcho = $false
        listPlayersCommandSeen = $false
        suspiciousPrefixedCommand = $false
    }

    if($Text -match 'Message:\s+.*#listPlayers') {
        $result.ownChatEcho = $true
    }
    if($Text -match '#listPlayers') {
        $result.listPlayersCommandSeen = $true
    }
    if($Text -match 'Message:\s+.*t#listPlayers') {
        $result.suspiciousPrefixedCommand = $true
    }

    return [pscustomobject]$result
}

if(-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Missing config: $ConfigPath"
}

$cfg = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json

@"
============================================================
SCUM AdminBot v0.1.1 CHAT-STATE-FIX
============================================================
Purpose:
  1. Force a clean chat state before every probe.
  2. Send #listPlayers through the admin SCUM client.
  3. Force-close chat after the command.
  4. Capture SCUM.log delta and SteamID64 candidates.
NO AUTO-KICK IN THIS VERSION.
============================================================
"@ | Set-Content -LiteralPath $BotLog -Encoding UTF8

Log "Bot starting"
Log "probeIntervalSeconds=$($cfg.probeIntervalSeconds) captureSeconds=$($cfg.captureSeconds)"
Log "kickEnabled=False (probe safety)"
Log "chatStateFix=True"

$lastPid = 0

while($true) {
    try {
        $p = Get-ScumProcess
        if(-not $p) {
            if($lastPid -ne 0) {
                Log "SCUM exited"
                $lastPid = 0
            }
            Start-Sleep -Seconds 2
            continue
        }

        if($lastPid -ne $p.Id) {
            $lastPid = $p.Id
            Log "SCUM found PID=$($p.Id)"
        }

        $scumLog = Get-ScumLogPath
        if(-not $scumLog) {
            Log "SCUM.log not found yet"
            Start-Sleep -Seconds 3
            continue
        }

        $before = (Get-Item -LiteralPath $scumLog).Length
        Log "PROBE start logOffset=$before path=$scumLog"

        $ok = Send-ScumCommand -Process $p -Command "#listPlayers"
        if(-not $ok) {
            Start-Sleep -Seconds ([int]$cfg.probeIntervalSeconds)
            continue
        }

        Start-Sleep -Seconds ([int]$cfg.captureSeconds)

        $delta = Read-NewLogBytes -Path $scumLog -StartOffset $before
        $ids = Get-SteamIdsFromText -Text $delta
        $class = Classify-Capture -Text $delta

        Log "PROBE deltaChars=$($delta.Length) steamIdCandidates=$($ids.Count)"
        Log "CAPTURE CLASS ownChatEcho=$($class.ownChatEcho) prefixedT=$($class.suspiciousPrefixedCommand)"

        foreach($id in $ids) {
            Log "STEAMID CANDIDATE $id"
        }

        $captureDir = Join-Path $Root "captures"
        New-Item -ItemType Directory -Force -Path $captureDir | Out-Null
        $capture = Join-Path $captureDir ("capture_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
        Set-Content -LiteralPath $capture -Value $delta -Encoding UTF8
        Log "CAPTURE saved $capture"

        Start-Sleep -Seconds ([int]$cfg.probeIntervalSeconds)
    }
    catch {
        Log "ERROR $($_.Exception.ToString())"
        Start-Sleep -Seconds 5
    }
}
