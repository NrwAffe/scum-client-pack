SCUM AdminBot v0.1.1 CHAT-STATE-FIX
===================================

Aenderung gegenueber v0.1.0:
- vor jedem Probe-Zyklus ESC
- danach T zum Oeffnen des Chats
- #listPlayers
- ENTER
- danach erneut ESC

Ziel:
Verhindern, dass ein offen gebliebenes Chatfeld beim naechsten Zyklus aus
T + #listPlayers versehentlich "t#listPlayers" macht.

Diese Version kickt weiterhin NIEMANDEN.

Test:
1. Mit Admin-Account auf den SCUM-Server verbinden.
2. START-ADMINBOT.bat starten.
3. Zwei Probe-Zyklen laufen lassen.
4. AdminBot.log und die neueste capture_*.txt hochladen.

Wichtige Logzeilen:
- INPUT STATE: pre-command ESC
- INPUT STATE: chat open key T
- COMMAND SENT: #listPlayers
- INPUT STATE: post-command ESC
- CAPTURE CLASS ownChatEcho=... prefixedT=...

Wenn prefixedT=False bleibt, ist der Chat-State-Fix erfolgreich.
