HideOwnMapMarker v0.2.3 OFFSET DIAG
==================================

READ-ONLY Diagnose fuer den aktuellen SCUM-Build.

Ziel:
Den neuen Feld-Offset innerhalb BP_PrisonerHUD_C finden, der auf
T_player_marker_smaller zeigt.

Diese Version schreibt NICHT in SCUM.

Test:
1. Alte HideOwnMapMarker-Version ersetzen.
2. SCUM komplett schliessen.
3. Launcher starten.
4. SCUM mit -nobattleye starten.
5. Vollstaendig auf den Server einloggen/spawnen.
6. Karte mindestens einmal oeffnen.
7. 20-30 Sekunden warten.
8. HideOwnMapMarker.log hochladen.

Gesucht wird eine Zeile:
HUD CANDIDATE ... OFFSET=0x...

Danach kann daraus die neue Patch-Version gebaut werden.
