﻿param(
    [switch]$Debug
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigFile = Join-Path $Root "Config\config.json"
$LogFile = Join-Path $Root "VoiceRadiusClient.log"

function Log([string]$m) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $m
    Add-Content -LiteralPath $LogFile -Value $line
    if($Debug){ Write-Host $line }
}

$config = Get-Content -LiteralPath $ConfigFile -Raw | ConvertFrom-Json

$src = @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

public static class VoiceRadiusKeys
{
    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    public const int WH_KEYBOARD_LL = 13;
    public const int WM_KEYDOWN = 0x0100;
    public const int WM_SYSKEYDOWN = 0x0104;

    [StructLayout(LayoutKind.Sequential)]
    public struct KBDLLHOOKSTRUCT
    {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [DllImport("user32.dll")]
    public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll")]
    public static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    public static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll")]
    public static extern short GetKeyState(int nVirtKey);

    public static bool IsScumForeground()
    {
        IntPtr hwnd = GetForegroundWindow();
        if(hwnd == IntPtr.Zero) return false;

        uint pid;
        GetWindowThreadProcessId(hwnd, out pid);

        try
        {
            Process p = Process.GetProcessById((int)pid);
            return String.Equals(p.ProcessName, "SCUM", StringComparison.OrdinalIgnoreCase);
        }
        catch { return false; }
    }

    public static char VkToSimpleChar(Keys key)
    {
        bool shift = (GetKeyState(0x10) & 0x8000) != 0;

        if(key >= Keys.A && key <= Keys.Z)
        {
            char c = (char)('a' + ((int)key - (int)Keys.A));
            return shift ? Char.ToUpperInvariant(c) : c;
        }

        if(key >= Keys.D0 && key <= Keys.D9)
            return (char)('0' + ((int)key - (int)Keys.D0));

        switch(key)
        {
            case Keys.Space: return ' ';
            case Keys.OemMinus: return shift ? '_' : '-';
            case Keys.OemPeriod: return '.';
            case Keys.Oemcomma: return ',';
            case Keys.OemQuestion: return shift ? '?' : '/';
            case Keys.Oem1: return shift ? ':' : ';';
            case Keys.Oem7: return shift ? '"' : '\'';
            default: return '\0';
        }
    }
}
'@

Add-Type -TypeDefinition $src -Language CSharp

$script:mode = [string]$config.defaultMode
$script:typed = ""
$script:lastActivity = Get-Date

function Get-ModeInfo([string]$mode) {
    switch($mode.ToLowerInvariant()) {
        "whisper" {
            return [pscustomobject]@{
                Label = "WHISPER"
                Meters = [int]$config.radiiMeters.whisper
                Diameter = [int]$config.ringPixels.whisper
            }
        }
        "shout" {
            return [pscustomobject]@{
                Label = "SHOUT"
                Meters = [int]$config.radiiMeters.shout
                Diameter = [int]$config.ringPixels.shout
            }
        }
        default {
            return [pscustomobject]@{
                Label = "NORMAL"
                Meters = [int]$config.radiiMeters.normal
                Diameter = [int]$config.ringPixels.normal
            }
        }
    }
}

$form = New-Object System.Windows.Forms.Form
$form.FormBorderStyle = "None"
$form.ShowInTaskbar = $false
$form.TopMost = $true
$form.BackColor = [Drawing.Color]::Magenta
$form.TransparencyKey = [Drawing.Color]::Magenta
$form.StartPosition = "Manual"
$form.Width = 440
$form.Height = 440

# Put overlay near lower-right by default
$screen = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Left = [Math]::Max(0, $screen.Right - $form.Width - [int]$config.marginRight)
$form.Top  = [Math]::Max(0, $screen.Bottom - $form.Height - [int]$config.marginBottom)

# Click-through + no activation
$WS_EX_LAYERED = 0x00080000
$WS_EX_TRANSPARENT = 0x00000020
$WS_EX_TOOLWINDOW = 0x00000080
$GWL_EXSTYLE = -20

$win32 = @'
using System;
using System.Runtime.InteropServices;
public static class VRWindow {
    [DllImport("user32.dll")]
    public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll")]
    public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
}
'@
Add-Type -TypeDefinition $win32 -Language CSharp

$form.Add_Shown({
    $style = [VRWindow]::GetWindowLong($form.Handle, $GWL_EXSTYLE)
    [VRWindow]::SetWindowLong($form.Handle, $GWL_EXSTYLE, $style -bor $WS_EX_LAYERED -bor $WS_EX_TRANSPARENT -bor $WS_EX_TOOLWINDOW) | Out-Null
})

$form.Add_Paint({
    param($sender,$e)

    $info = Get-ModeInfo $script:mode
    $g = $e.Graphics
    $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias

    $cx = [int]($form.ClientSize.Width / 2)
    $cy = [int]($form.ClientSize.Height / 2)
    $d = [int]$info.Diameter
    $x = $cx - [int]($d/2)
    $y = $cy - [int]($d/2)

    $pen = New-Object Drawing.Pen([Drawing.Color]::FromArgb(225,255,255,255), 3)
    $pen.DashStyle = [Drawing.Drawing2D.DashStyle]::Dash
    $g.DrawEllipse($pen,$x,$y,$d,$d)
    $pen.Dispose()

    $fill = New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(90,0,0,0))
    $box = New-Object Drawing.RectangleF(88,178,264,84)
    $g.FillRectangle($fill,$box)
    $fill.Dispose()

    $font1 = New-Object Drawing.Font("Segoe UI",18,[Drawing.FontStyle]::Bold)
    $font2 = New-Object Drawing.Font("Segoe UI",11,[Drawing.FontStyle]::Regular)
    $brush = New-Object Drawing.SolidBrush([Drawing.Color]::White)

    $text1 = "{0}  |  {1} m" -f $info.Label,$info.Meters
    $sz = $g.MeasureString($text1,$font1)
    $g.DrawString($text1,$font1,$brush,$cx-$sz.Width/2,187)

    $text2 = "Voice Radius"
    $sz2 = $g.MeasureString($text2,$font2)
    $g.DrawString($text2,$font2,$brush,$cx-$sz2.Width/2,225)

    $brush.Dispose()
    $font1.Dispose()
    $font2.Dispose()
})

function Set-Mode([string]$newMode) {
    $newMode = $newMode.ToLowerInvariant()
    if($newMode -notin @("whisper","normal","shout")) { return }

    if($script:mode -ne $newMode) {
        $script:mode = $newMode
        $info = Get-ModeInfo $newMode
        Log "MODE -> $($info.Label) / $($info.Meters)m"
        $form.Invalidate()
    }
}

$proc = [VoiceRadiusKeys+LowLevelKeyboardProc]{
    param($nCode,$wParam,$lParam)

    if($nCode -ge 0 -and (($wParam.ToInt32() -eq [VoiceRadiusKeys]::WM_KEYDOWN) -or ($wParam.ToInt32() -eq [VoiceRadiusKeys]::WM_SYSKEYDOWN))) {
        if([VoiceRadiusKeys]::IsScumForeground()) {
            $data = [Runtime.InteropServices.Marshal]::PtrToStructure($lParam,[type][VoiceRadiusKeys+KBDLLHOOKSTRUCT])
            $key = [System.Windows.Forms.Keys]$data.vkCode

            if($key -eq [System.Windows.Forms.Keys]::Enter) {
                $cmd = $script:typed.Trim().ToLowerInvariant()
                if($cmd.EndsWith("!vw")) { Set-Mode "whisper" }
                elseif($cmd.EndsWith("!vn")) { Set-Mode "normal" }
                elseif($cmd.EndsWith("!vs")) { Set-Mode "shout" }

                $script:typed = ""
            }
            elseif($key -eq [System.Windows.Forms.Keys]::Back) {
                if($script:typed.Length -gt 0) {
                    $script:typed = $script:typed.Substring(0,$script:typed.Length-1)
                }
            }
            elseif($key -eq [System.Windows.Forms.Keys]::Escape) {
                $script:typed = ""
            }
            else {
                $c = [VoiceRadiusKeys]::VkToSimpleChar($key)
                if($c -ne [char]0) {
                    $script:typed += $c
                    if($script:typed.Length -gt 64) {
                        $script:typed = $script:typed.Substring($script:typed.Length-64)
                    }
                }

                # Optional fallback hotkeys while SCUM is focused:
                if($key -eq [System.Windows.Forms.Keys]::F6) { Set-Mode "whisper" }
                elseif($key -eq [System.Windows.Forms.Keys]::F7) { Set-Mode "normal" }
                elseif($key -eq [System.Windows.Forms.Keys]::F8) { Set-Mode "shout" }
            }
        }
    }

    return [VoiceRadiusKeys]::CallNextHookEx([IntPtr]::Zero,$nCode,$wParam,$lParam)
}

$module = [Diagnostics.Process]::GetCurrentProcess().MainModule
$hMod = [VoiceRadiusKeys]::GetModuleHandle($module.ModuleName)
$hook = [VoiceRadiusKeys]::SetWindowsHookEx([VoiceRadiusKeys]::WH_KEYBOARD_LL,$proc,$hMod,0)

if($hook -eq [IntPtr]::Zero) {
    throw "Keyboard hook konnte nicht gesetzt werden."
}

Log "VoiceRadiusClient gestartet."
Log "Commands: !vw / !vn / !vs | Fallback: F6/F7/F8"
Log ("Default: " + (Get-ModeInfo $script:mode).Label)

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1000
$timer.Add_Tick({
    $scum = Get-Process -Name SCUM -ErrorAction SilentlyContinue | Select-Object -First 1

    if($scum) {
        if(-not $form.Visible) { $form.Show() }
    } else {
        if($config.exitWhenScumCloses -eq $true) {
            $timer.Stop()
            $form.Close()
        }
    }
})
$timer.Start()

try {
    [void]$form.ShowDialog()
}
finally {
    if($hook -ne [IntPtr]::Zero) {
        [VoiceRadiusKeys]::UnhookWindowsHookEx($hook) | Out-Null
    }
}
