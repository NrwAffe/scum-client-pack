VoiceRadiusClient v0.1.0
=========================

CLIENT-TEIL fuer VoiceRadius.

Serverwerte aus der vorhandenen VoiceRadius-Mod:
- Whisper: 300 UE ~= 3 m
- Normal : 1500 UE ~= 15 m
- Shout  : 4000 UE ~= 40 m

Server-Kommandos:
- !vw = Whisper
- !vn = Normal
- !vs = Shout


WAS MACHT DIESER CLIENT?
------------------------
Der Client zeigt ein transparentes Overlay mit:

  WHISPER | 3 m
  NORMAL  | 15 m
  SHOUT   | 40 m

plus einem Ringindikator, der je nach Modus groesser/kleiner wird.

Der Client beobachtet nur die Tastatureingabe, waehrend SCUM
im Vordergrund ist.

Wenn der Spieler in SCUM eingibt:

  !vw + Enter
  !vn + Enter
  !vs + Enter

wird der visuelle Modus entsprechend aktualisiert.

Fallback:
  F6 = Whisper
  F7 = Normal
  F8 = Shout


WICHTIG
-------
- Keine Injection.
- Kein UE4SS.
- Keine SCUM-Speicherwrites.
- Kein Anti-Cheat-Bypass.
- Der Client veraendert die Voice-Reichweite NICHT.
  Die echte Voice-Reichweite bleibt vollstaendig serverseitig.
- Der Client visualisiert nur den aktuell ausgewaehlten Modus.


GENAUIGKEIT DES RINGS
---------------------
v0.1.0 zeigt einen HUD-Ring als visuellen Reichweitenindikator.

Der Ring ist noch KEIN geometrisch exakter 3/15/40-Meter-Kreis
in der 3D-Welt oder auf der SCUM-Karte.

Fuer einen exakt skalierten Welt-/Map-Radius muessen noch
Kameraprojektion bzw. Karten-Zoom und Markerposition ermittelt werden.


INSTALLATION
------------
Ordner entpacken und:

  START-VOICE-RADIUS-CLIENT.bat

starten.

Der Prozess beendet sich automatisch, wenn SCUM geschlossen wird.


GITHUB / LAUNCHER
-----------------
Der komplette Ordner kann als ZIP auf GitHub abgelegt werden.

Empfohlen:
  client-packages/VoiceRadiusClient_v0.1.0.zip

Im Launcher-Manifest kann dieser ZIP dann in einen Client-Mod-Ordner
installiert werden.

Fuer automatisches Starten ueber den Launcher sollte der Launcher
einen client_helper/startWithGame-Modtyp bekommen.
