HideOwnMapMarker v0.3.0 FINAL
==============================

Runtime-bestaetigt fuer den aktuellen SCUM-Build:

  BP_PrisonerHUD_C + 0x638 -> T_player_marker_smaller
  BP_PrisonerHUD_C + 0x640 -> GradientCircle

Wirkung:
- eigener roter GPS-/Map-Marker wird entfernt
- pulsierender GPS-Kreis wird entfernt

Sicherheit:
- kein blindes Schreiben
- +0x638 wird nur gepatcht, wenn dort T_player_marker_smaller gefunden wurde
- +0x640 wird nur gepatcht, wenn dort GradientCircle / Texture2D liegt
- beide Writes werden direkt verifiziert
- originale Pointer werden beim Beenden des Helpers wiederhergestellt

Start:
Der Launcher soll direkt starten:
  Scripts\HideOwnMapMarker.ps1

Empfohlener Manifest-Eintrag:
  "clientHelper": {
    "executable": "Scripts\\HideOwnMapMarker.ps1",
    "startWithGame": true
  }

Nur -nobattleye / private Testumgebung.
