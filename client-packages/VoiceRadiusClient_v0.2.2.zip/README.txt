VoiceRadiusClient v0.2.2

Diagnose-/Fix-Version:
- Overlay erscheint bereits vor SCUM mit "VoiceRadius läuft - warte auf SCUM".
- Sobald SCUM erkannt wird: NORMAL | 15 m + Kreis.
- ^ wird per ScanCode 41 sowie VK 192/220/226 erkannt.
- F9 ist ein sicherer Test-Fallback.
- Jeder Tastendruck bei SCUM im Vordergrund wird mit VK/ScanCode geloggt.
- Fenster wird alle 500 ms erneut TOPMOST gesetzt.

WICHTIG:
Externe Windows-Overlays können in exklusivem Fullscreen unsichtbar sein.
Zum Test SCUM auf Borderless/Windowed stellen.

Log:
VoiceRadiusClient.log
