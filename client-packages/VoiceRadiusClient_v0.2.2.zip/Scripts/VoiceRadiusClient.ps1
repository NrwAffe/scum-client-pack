﻿param([switch]$Debug)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigFile = Join-Path $Root "Config\config.json"
$LogFile = Join-Path $Root "VoiceRadiusClient.log"

function Log([string]$m) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $m
    Add-Content -LiteralPath $LogFile -Value $line
    if($Debug){ Write-Host $line }
}

$config = Get-Content -LiteralPath $ConfigFile -Raw | ConvertFrom-Json

$native = @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

public static class VRNative
{
    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    public const int WH_KEYBOARD_LL = 13;
    public const int WM_KEYDOWN = 0x0100;
    public const int WM_SYSKEYDOWN = 0x0104;

    public static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
    public const uint SWP_NOMOVE = 0x0002;
    public const uint SWP_NOSIZE = 0x0001;
    public const uint SWP_NOACTIVATE = 0x0010;
    public const uint SWP_SHOWWINDOW = 0x0040;

    [StructLayout(LayoutKind.Sequential)]
    public struct KBDLLHOOKSTRUCT {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [DllImport("user32.dll")] public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
    [DllImport("user32.dll")] public static extern bool UnhookWindowsHookEx(IntPtr hhk);
    [DllImport("user32.dll")] public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("kernel32.dll", CharSet=CharSet.Auto, SetLastError=true)] public static extern IntPtr GetModuleHandle(string lpModuleName);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr insertAfter, int X, int Y, int cx, int cy, uint flags);

    public static bool IsScumForeground()
    {
        IntPtr hwnd = GetForegroundWindow();
        if(hwnd == IntPtr.Zero) return false;
        uint pid;
        GetWindowThreadProcessId(hwnd, out pid);
        try {
            Process p = Process.GetProcessById((int)pid);
            return String.Equals(p.ProcessName, "SCUM", StringComparison.OrdinalIgnoreCase);
        } catch { return false; }
    }

    public static bool IsScumRunning()
    {
        try { return Process.GetProcessesByName("SCUM").Length > 0; }
        catch { return false; }
    }
}
'@
Add-Type -TypeDefinition $native -Language CSharp

$script:modes = @("whisper","normal","shout")
$script:mode = [string]$config.defaultMode
if($script:modes -notcontains $script:mode.ToLowerInvariant()){ $script:mode = "normal" }
$script:sending = $false
$script:lastToggle = [DateTime]::MinValue
$script:seenScum = $false
$script:scumRunning = $false

function ModeInfo([string]$m) {
    switch($m.ToLowerInvariant()) {
        "whisper" { return [pscustomobject]@{Label="WHISPER";Meters=3;Diameter=[int]$config.ringPixels.whisper;Command="!vw"} }
        "shout"   { return [pscustomobject]@{Label="SHOUT";Meters=40;Diameter=[int]$config.ringPixels.shout;Command="!vs"} }
        default   { return [pscustomobject]@{Label="NORMAL";Meters=15;Diameter=[int]$config.ringPixels.normal;Command="!vn"} }
    }
}

function Send-ServerCommand([string]$cmd) {
    if(-not [VRNative]::IsScumForeground()) {
        Log "Command '$cmd' nicht gesendet: SCUM nicht im Vordergrund."
        return
    }

    try {
        $script:sending=$true
        [Windows.Forms.SendKeys]::SendWait("{ENTER}")
        Start-Sleep -Milliseconds ([int]$config.chat.openDelayMs)
        [Windows.Forms.SendKeys]::SendWait($cmd)
        Start-Sleep -Milliseconds ([int]$config.chat.typeDelayMs)
        [Windows.Forms.SendKeys]::SendWait("{ENTER}")
        Log "Serverbefehl gesendet: $cmd"
    } catch {
        Log "Command-Fehler: $($_.Exception.Message)"
    } finally {
        Start-Sleep -Milliseconds 120
        $script:sending=$false
    }
}

function Set-Mode([string]$m) {
    $script:mode=$m
    $i=ModeInfo $m
    Log "MODE -> $($i.Label) / $($i.Meters)m"
    $form.Invalidate()
    if($config.sendServerCommand -eq $true){ Send-ServerCommand $i.Command }
}

function Next-Mode {
    $idx=[Array]::IndexOf($script:modes,$script:mode.ToLowerInvariant())
    if($idx -lt 0){$idx=1}
    Set-Mode $script:modes[(($idx+1)%$script:modes.Count)]
}

$form=New-Object Windows.Forms.Form
$form.FormBorderStyle="None"
$form.ShowInTaskbar=$true
$form.TopMost=$true
$form.BackColor=[Drawing.Color]::Fuchsia
$form.TransparencyKey=[Drawing.Color]::Fuchsia
$form.StartPosition="Manual"
$form.Width=500
$form.Height=500

$screen=[Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Left=[Math]::Max(0,$screen.Right-$form.Width-[int]$config.marginRight)
$form.Top=[Math]::Max(0,$screen.Bottom-$form.Height-[int]$config.marginBottom)

$form.Add_Paint({
    param($s,$e)
    $g=$e.Graphics
    $g.SmoothingMode=[Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $cx=[int]($form.ClientSize.Width/2)
    $cy=[int]($form.ClientSize.Height/2)

    if(-not $script:scumRunning) {
        $b=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(220,0,0,0))
        $g.FillRectangle($b,90,200,320,90); $b.Dispose()
        $f=New-Object Drawing.Font("Segoe UI",16,[Drawing.FontStyle]::Bold)
        $br=New-Object Drawing.SolidBrush([Drawing.Color]::White)
        $t="VoiceRadius läuft - warte auf SCUM"
        $sz=$g.MeasureString($t,$f)
        $g.DrawString($t,$f,$br,$cx-$sz.Width/2,225)
        $br.Dispose(); $f.Dispose()
        return
    }

    $i=ModeInfo $script:mode
    $d=[int]$i.Diameter
    $x=$cx-[int]($d/2); $y=$cy-[int]($d/2)

    $pen=New-Object Drawing.Pen([Drawing.Color]::FromArgb(245,255,255,255),5)
    $pen.DashStyle=[Drawing.Drawing2D.DashStyle]::Dash
    $g.DrawEllipse($pen,$x,$y,$d,$d)
    $pen.Dispose()

    $fill=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(195,0,0,0))
    $g.FillRectangle($fill,95,197,310,100); $fill.Dispose()

    $f1=New-Object Drawing.Font("Segoe UI",22,[Drawing.FontStyle]::Bold)
    $f2=New-Object Drawing.Font("Segoe UI",11)
    $br=New-Object Drawing.SolidBrush([Drawing.Color]::White)

    $t1="{0}  |  {1} m" -f $i.Label,$i.Meters
    $sz1=$g.MeasureString($t1,$f1)
    $g.DrawString($t1,$f1,$br,$cx-$sz1.Width/2,205)

    $t2="^ = Reichweite wechseln   |   F9 = Test"
    $sz2=$g.MeasureString($t2,$f2)
    $g.DrawString($t2,$f2,$br,$cx-$sz2.Width/2,255)

    $br.Dispose(); $f1.Dispose(); $f2.Dispose()
})

$proc=[VRNative+LowLevelKeyboardProc]{
    param($nCode,$wParam,$lParam)

    if($nCode -ge 0 -and -not $script:sending -and (($wParam.ToInt32() -eq [VRNative]::WM_KEYDOWN) -or ($wParam.ToInt32() -eq [VRNative]::WM_SYSKEYDOWN))) {
        $k=[Runtime.InteropServices.Marshal]::PtrToStructure($lParam,[type][VRNative+KBDLLHOOKSTRUCT])
        $vk=[int]$k.vkCode
        $sc=[int]$k.scanCode

        if([VRNative]::IsScumForeground()) {
            Log "KEY VK=$vk SC=$sc"
            $cycle=($sc -eq 41) -or ($vk -in @(192,220,226)) -or ($vk -eq [int][Windows.Forms.Keys]::F9)
            if($cycle) {
                $now=Get-Date
                if(($now-$script:lastToggle).TotalMilliseconds -ge [int]$config.debounceMs) {
                    $script:lastToggle=$now
                    Log "Cycle-Key erkannt."
                    Next-Mode
                }
            }
        }
    }

    return [VRNative]::CallNextHookEx([IntPtr]::Zero,$nCode,$wParam,$lParam)
}

$module=[Diagnostics.Process]::GetCurrentProcess().MainModule
$hook=[VRNative]::SetWindowsHookEx([VRNative]::WH_KEYBOARD_LL,$proc,[VRNative]::GetModuleHandle($module.ModuleName),0)
if($hook -eq [IntPtr]::Zero){ throw "Keyboard Hook konnte nicht gesetzt werden." }

Log "VoiceRadiusClient v0.2.2 gestartet. PID=$PID"
Log "Wenn dieses Fenster/Overlay nicht sichtbar ist, wurde der Helper nicht gestartet."
Log "Fuer externe Overlays SCUM bitte Borderless/Windowed statt exklusivem Fullscreen testen."

$timer=New-Object Windows.Forms.Timer
$timer.Interval=500
$timer.Add_Tick({
    $running=[VRNative]::IsScumRunning()
    if($running -ne $script:scumRunning) {
        $script:scumRunning=$running
        if($running) {
            $script:seenScum=$true
            Log "SCUM erkannt -> Overlay im Spielmodus."
        } else {
            Log "SCUM nicht erkannt."
        }
        $form.Invalidate()
    }

    # Reassert TOPMOST. External overlays may otherwise end up behind borderless games.
    if($form.IsHandleCreated) {
        [VRNative]::SetWindowPos(
            $form.Handle,
            [VRNative]::HWND_TOPMOST,
            0,0,0,0,
            [VRNative]::SWP_NOMOVE -bor [VRNative]::SWP_NOSIZE -bor [VRNative]::SWP_NOACTIVATE -bor [VRNative]::SWP_SHOWWINDOW
        ) | Out-Null
    }

    if($script:seenScum -and -not $running -and $config.exitAfterScumCloses -eq $true) {
        $timer.Stop()
        $form.Close()
    }
})
$timer.Start()

try { [void]$form.ShowDialog() }
finally {
    if($hook -ne [IntPtr]::Zero){ [VRNative]::UnhookWindowsHookEx($hook)|Out-Null }
}
