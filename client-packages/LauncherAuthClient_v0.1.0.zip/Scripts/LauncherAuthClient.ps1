﻿$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$ConfigPath = Join-Path $Root "Config\config.json"
$SecretPath = Join-Path $Root "Config\launcher-secret.txt"
$LogPath = Join-Path $Root "LauncherAuthClient.log"

function Log([string]$s) {
    Add-Content -LiteralPath $LogPath -Value ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss.fff"), $s) -Encoding UTF8
}

function Get-SteamId64 {
    $candidates = @(
        "${env:ProgramFiles(x86)}\Steam\config\loginusers.vdf",
        "$env:ProgramFiles\Steam\config\loginusers.vdf"
    )
    foreach($p in $candidates) {
        if(-not (Test-Path -LiteralPath $p)) { continue }
        $lines = Get-Content -LiteralPath $p
        $current = $null
        $mostRecent = $false
        foreach($line in $lines) {
            if($line -match '^\s*"(\d{17})"\s*$') {
                if($current -and $mostRecent) { return $current }
                $current = $Matches[1]
                $mostRecent = $false
                continue
            }
            if($current -and $line -match '"MostRecent"\s*"1"') {
                $mostRecent = $true
            }
        }
        if($current -and $mostRecent) { return $current }
    }
    return $null
}

if(-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Config fehlt: $ConfigPath"
}
$cfg = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
if(-not $cfg.authBaseUrl -or -not $cfg.serverId) {
    throw "authBaseUrl/serverId fehlen in config.json"
}
if(-not (Test-Path -LiteralPath $SecretPath)) {
    Log "ENROLLMENT REQUIRED: Config\launcher-secret.txt fehlt"
    exit 2
}

$secret = (Get-Content -LiteralPath $SecretPath -Raw).Trim()
$steamId = Get-SteamId64
if(-not $steamId) {
    Log "ERROR SteamID64 konnte nicht aus Steam loginusers.vdf ermittelt werden"
    exit 3
}

Log "SteamID=$steamId serverId=$($cfg.serverId)"

$body = @{
    steamId = $steamId
    serverId = [string]$cfg.serverId
    launcherSecret = $secret
} | ConvertTo-Json -Compress

try {
    $r = Invoke-RestMethod -Method Post -Uri ($cfg.authBaseUrl.TrimEnd('/') + "/v1/client/authorize") `
        -ContentType "application/json" -Body $body -TimeoutSec 10
    Log "AUTHORIZED expiresAt=$($r.expiresAt) ttl=$($r.ttlSeconds)"
} catch {
    Log "AUTHORIZE FAILED: $($_.Exception.Message)"
    exit 4
}

$heartbeat = 30
if($cfg.heartbeatSeconds) { $heartbeat = [int]$cfg.heartbeatSeconds }

while($true) {
    Start-Sleep -Seconds $heartbeat
    try {
        $r = Invoke-RestMethod -Method Post -Uri ($cfg.authBaseUrl.TrimEnd('/') + "/v1/client/heartbeat") `
            -ContentType "application/json" -Body $body -TimeoutSec 10
        Log "HEARTBEAT ok expiresAt=$($r.expiresAt)"
    } catch {
        Log "HEARTBEAT FAILED: $($_.Exception.Message)"
    }
}
