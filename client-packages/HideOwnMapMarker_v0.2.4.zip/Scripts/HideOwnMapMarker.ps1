﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Log = Join-Path $Root "HideOwnMapMarker.log"

@"
============================================================
HideOwnMapMarker v0.2.4 CURRENT BUILD
============================================================
Confirmed current-build path:
BP_PrisonerHUD_C + 0x638 -> T_player_marker_smaller

External helper. No injection / no hooks.
NO-BATTLEYE / PRIVATE TEST ONLY.
"@ | Set-Content -LiteralPath $Log -Encoding UTF8

$src = @'
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public static class HideOwnMapMarker024
{
    const uint PROCESS_VM_OPERATION=0x0008;
    const uint PROCESS_VM_READ=0x0010;
    const uint PROCESS_VM_WRITE=0x0020;
    const uint PROCESS_QUERY_INFORMATION=0x0400;
    const uint MEM_COMMIT=0x1000;
    const uint MEM_PRIVATE=0x20000;
    const uint MEM_IMAGE=0x1000000;
    const uint PAGE_NOACCESS=0x01;
    const uint PAGE_GUARD=0x100;

    const long MARKER_OFFSET=0x638;

    [StructLayout(LayoutKind.Sequential)]
    struct MEMORY_BASIC_INFORMATION {
        public IntPtr BaseAddress;
        public IntPtr AllocationBase;
        public uint AllocationProtect;
        public UIntPtr RegionSize;
        public uint State;
        public uint Protect;
        public uint Type;
    }

    [DllImport("kernel32.dll", SetLastError=true)]
    static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool ReadProcessMemory(IntPtr h, IntPtr addr, byte[] buffer, IntPtr size, out IntPtr read);
    [DllImport("kernel32.dll", SetLastError=true)]
    static extern bool WriteProcessMemory(IntPtr h, IntPtr addr, byte[] buffer, IntPtr size, out IntPtr written);
    [DllImport("kernel32.dll")]
    static extern IntPtr VirtualQueryEx(IntPtr h, IntPtr addr, out MEMORY_BASIC_INFORMATION mbi, IntPtr len);
    [DllImport("kernel32.dll")]
    static extern bool CloseHandle(IntPtr h);

    class Region { public long Base,Size; public uint Type,Protect; }

    static IntPtr H;
    static long ImageBase,ImageEnd;
    static string LogPath;
    static long FNameTable;
    static int FNameBlockCount;
    static readonly Dictionary<long,long> Originals=new Dictionary<long,long>();

    static void Log(string s) {
        File.AppendAllText(LogPath,"["+DateTime.Now.ToString("HH:mm:ss.fff")+"] "+s+Environment.NewLine,Encoding.UTF8);
    }

    static bool Read(long a, byte[] b) {
        IntPtr got;
        return ReadProcessMemory(H,new IntPtr(a),b,new IntPtr(b.Length),out got) && got.ToInt64()==b.Length;
    }
    static long U64(long a){var b=new byte[8]; return Read(a,b)?BitConverter.ToInt64(b,0):0;}
    static int I32(long a){var b=new byte[4]; return Read(a,b)?BitConverter.ToInt32(b,0):0;}
    static ushort U16(long a){var b=new byte[2]; return Read(a,b)?BitConverter.ToUInt16(b,0):(ushort)0;}

    static bool W64(long a,long v){
        var b=BitConverter.GetBytes(v);
        IntPtr wrote;
        bool ok=WriteProcessMemory(H,new IntPtr(a),b,new IntPtr(8),out wrote) && wrote.ToInt64()==8;
        Log("WRITE addr=0x"+a.ToString("X")+" value=0x"+v.ToString("X")+" ok="+ok+" err="+Marshal.GetLastWin32Error());
        return ok;
    }

    static bool IsReadable(uint p){return (p&PAGE_NOACCESS)==0 && (p&PAGE_GUARD)==0;}

    static List<Region> Regions() {
        var rs=new List<Region>();
        long a=0; int sz=Marshal.SizeOf(typeof(MEMORY_BASIC_INFORMATION));
        while(a<0x00007FFFFFFF0000L){
            MEMORY_BASIC_INFORMATION m;
            if(VirtualQueryEx(H,new IntPtr(a),out m,new IntPtr(sz))==IntPtr.Zero) break;
            long b=m.BaseAddress.ToInt64(), s=(long)m.RegionSize.ToUInt64();
            if(s<=0) break;
            if(m.State==MEM_COMMIT && IsReadable(m.Protect))
                rs.Add(new Region{Base=b,Size=s,Type=m.Type,Protect=m.Protect});
            long n=b+s; if(n<=a) break; a=n;
        }
        return rs;
    }

    static Region FindRegion(List<Region> rs,long a){
        foreach(var r in rs) if(a>=r.Base && a<r.Base+r.Size) return r;
        return null;
    }

    static IEnumerable<long> FindBytes(Region r, byte[] needle) {
        const int CHUNK=4*1024*1024;
        int overlap=Math.Max(0,needle.Length-1);
        long pos=0; byte[] carry=new byte[0];
        while(pos<r.Size){
            int want=(int)Math.Min(CHUNK,r.Size-pos);
            byte[] part=new byte[want];
            if(!Read(r.Base+pos,part)){pos+=want;carry=new byte[0];continue;}
            byte[] buf=new byte[carry.Length+part.Length];
            Buffer.BlockCopy(carry,0,buf,0,carry.Length);
            Buffer.BlockCopy(part,0,buf,carry.Length,part.Length);
            for(int i=0;i<=buf.Length-needle.Length;i++){
                bool ok=true;
                for(int j=0;j<needle.Length;j++) if(buf[i+j]!=needle[j]){ok=false;break;}
                if(ok) yield return r.Base+pos-carry.Length+i;
            }
            int keep=Math.Min(overlap,buf.Length);
            carry=new byte[keep];
            if(keep>0) Buffer.BlockCopy(buf,buf.Length-keep,carry,0,keep);
            pos+=want;
        }
    }

    static long FindFNameEntry(List<Region> rs,string text){
        byte[] n=Encoding.ASCII.GetBytes(text);
        foreach(var r in rs){
            if(r.Type!=MEM_PRIVATE) continue;
            foreach(long t in FindBytes(r,n)){
                long e=t-2; ushort h=U16(e);
                if((h&1)==0 && (h>>6)==text.Length) return e;
            }
        }
        return 0;
    }

    static long FindPtrInImage(long v){
        var r=new Region{Base=ImageBase,Size=ImageEnd-ImageBase,Type=MEM_IMAGE};
        foreach(long x in FindBytes(r,BitConverter.GetBytes(v))) return x;
        return 0;
    }

    static bool BuildFNameTable(List<Region> rs,long entry,string target){
        Region er=FindRegion(rs,entry); if(er==null) return false;
        long[] bases={er.Base,entry&~0xFFFL,entry&~0xFFFFL};
        foreach(long bb in bases){
            long slot=FindPtrInImage(bb); if(slot==0) continue;
            long start=slot;
            for(int i=0;i<4096;i++){
                long p=U64(start-8);
                Region rr=FindRegion(rs,p);
                if(rr==null || rr.Type!=MEM_PRIVATE) break;
                start-=8;
            }
            int count=0;
            for(int i=0;i<8192;i++){
                long p=U64(start+i*8L);
                Region rr=FindRegion(rs,p);
                if(rr==null || rr.Type!=MEM_PRIVATE) break;
                count++;
            }
            if(count<2) continue;
            long idx=(slot-start)/8, delta=entry-bb;
            if(idx<0 || idx>=count || delta<0 || delta>0x1FFFF) continue;
            FNameTable=start; FNameBlockCount=count;
            int id=((int)idx<<16)|((int)(delta/2)&0xFFFF);
            if(FName(id)==target) return true;
            FNameTable=0; FNameBlockCount=0;
        }
        return false;
    }

    static string FName(int id){
        if(FNameTable==0) return "";
        int block=(int)((uint)id>>16), off=id&0xFFFF;
        if(block<0 || block>=FNameBlockCount) return "";
        long bp=U64(FNameTable+block*8L); if(bp==0) return "";
        long e=bp+off*2L; ushort h=U16(e);
        int len=h>>6; bool wide=(h&1)!=0;
        if(len<=0 || len>512) return "";
        byte[] d=new byte[len*(wide?2:1)];
        if(!Read(e+2,d)) return "";
        return wide?Encoding.Unicode.GetString(d):Encoding.ASCII.GetString(d);
    }

    static string ObjName(long obj){return obj==0?"":FName(I32(obj+0x18));}
    static string ClassName(long obj){long c=U64(obj+0x10); return c==0?"":ObjName(c);}

    static int FindNameId(long entry,string target){
        for(int b=0;b<FNameBlockCount;b++){
            long bp=U64(FNameTable+b*8L); if(bp==0) continue;
            long d=entry-bp;
            if(d>=0 && d<0x20000 && (d%2)==0){
                int id=(b<<16)|((int)(d/2)&0xFFFF);
                if(FName(id)==target) return id;
            }
        }
        return -1;
    }

    static long FindTexture(List<Region> rs,int id,string target){
        byte[] needle=BitConverter.GetBytes(id);
        foreach(var r in rs){
            if(r.Type!=MEM_PRIVATE) continue;
            foreach(long hit in FindBytes(r,needle)){
                long obj=hit-0x18;
                long vt=U64(obj);
                if(vt<ImageBase || vt>=ImageEnd) continue;
                if(ObjName(obj)==target && ClassName(obj)=="Texture2D") return obj;
            }
        }
        return 0;
    }

    static long FindHudSlot(List<Region> rs,long marker){
        byte[] ptr=BitConverter.GetBytes(marker);
        foreach(var r in rs){
            if(r.Type!=MEM_PRIVATE) continue;
            foreach(long slot in FindBytes(r,ptr)){
                long hud=slot-MARKER_OFFSET;
                if(hud<=0) continue;
                long vt=U64(hud);
                if(vt<ImageBase || vt>=ImageEnd) continue;
                if(ClassName(hud)=="BP_PrisonerHUD_C"){
                    Log("HUD MATCH hud=0x"+hud.ToString("X")+" objName='"+ObjName(hud)+"' class='BP_PrisonerHUD_C' slot=0x"+slot.ToString("X")+" OFFSET=0x638");
                    return slot;
                }
            }
        }
        return 0;
    }

    static bool DiscoverAndPatch(){
        var rs=Regions();
        long entry=FindFNameEntry(rs,"T_player_marker_smaller");
        if(entry==0){Log("DISCOVERY FAIL: FName entry not found");return false;}
        if(!BuildFNameTable(rs,entry,"T_player_marker_smaller")){Log("DISCOVERY FAIL: FName table unresolved");return false;}
        int id=FindNameId(entry,"T_player_marker_smaller");
        if(id<0){Log("DISCOVERY FAIL: FNameId unresolved");return false;}
        long tex=FindTexture(rs,id,"T_player_marker_smaller");
        if(tex==0){Log("DISCOVERY FAIL: marker Texture2D UObject not found");return false;}
        Log("MARKER UObject=0x"+tex.ToString("X")+" name='"+ObjName(tex)+"' class='"+ClassName(tex)+"'");

        long slot=FindHudSlot(rs,tex);
        if(slot==0){Log("DISCOVERY FAIL: BP_PrisonerHUD_C +0x638 backref not found");return false;}

        long old=U64(slot);
        if(old!=tex){Log("PATCH REFUSED: slot no longer points to marker");return false;}
        Originals[slot]=old;

        bool ok=W64(slot,0);
        long verify=U64(slot);
        Log("PATCH CURRENTBUILD slot(+638)=0x"+slot.ToString("X")+" old=0x"+old.ToString("X")+" ok="+ok+" verify=0x"+verify.ToString("X"));
        return ok && verify==0;
    }

    static void Restore(){
        foreach(var kv in Originals){
            try{
                if(U64(kv.Key)==0){
                    bool ok=W64(kv.Key,kv.Value);
                    Log("RESTORE addr=0x"+kv.Key.ToString("X")+" ok="+ok);
                }
            }catch{}
        }
    }

    public static void Run(string logPath){
        LogPath=logPath;
        Process p=null;
        while(p==null){
            var ps=Process.GetProcessesByName("SCUM");
            if(ps.Length>0)p=ps[0]; else Thread.Sleep(500);
        }
        H=OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ|PROCESS_VM_WRITE|PROCESS_VM_OPERATION,false,p.Id);
        if(H==IntPtr.Zero){Log("OpenProcess failed err="+Marshal.GetLastWin32Error());return;}

        try{
            ImageBase=p.MainModule.BaseAddress.ToInt64();
            ImageEnd=ImageBase+p.MainModule.ModuleMemorySize;
            int pe=I32(ImageBase+0x3C);
            uint ts=(uint)I32(ImageBase+pe+8);
            Log("SCUM PID="+p.Id+" base=0x"+ImageBase.ToString("X")+" size=0x"+p.MainModule.ModuleMemorySize.ToString("X")+" timestamp=0x"+ts.ToString("X8"));

            bool patched=false;
            for(int attempt=1;attempt<=30 && !p.HasExited && !patched;attempt++){
                Log("DISCOVERY attempt="+attempt);
                FNameTable=0; FNameBlockCount=0;
                patched=DiscoverAndPatch();
                if(!patched) Thread.Sleep(3000);
            }

            if(patched){
                Log("SUCCESS: current-build self marker hidden");
                while(!p.HasExited) Thread.Sleep(1000);
            }
        }catch(Exception ex){
            Log("FATAL "+ex);
        }finally{
            try{ if(p!=null && !p.HasExited) Restore(); }catch{}
            if(H!=IntPtr.Zero) CloseHandle(H);
        }
    }
}
'@

try {
    Add-Type -TypeDefinition $src -Language CSharp
    [HideOwnMapMarker024]::Run($Log)
}
catch {
    Add-Content -LiteralPath $Log -Value ("["+$(Get-Date -Format "HH:mm:ss.fff")+"] POWERSHELL ERROR "+$_.Exception.ToString()) -Encoding UTF8
}
