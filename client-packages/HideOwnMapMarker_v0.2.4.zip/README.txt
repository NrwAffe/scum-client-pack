HideOwnMapMarker v0.2.4 CURRENT BUILD
====================================

Aktueller Build bestaetigt:
BP_PrisonerHUD_C + 0x638 -> T_player_marker_smaller

Diese Version entfernt NUR den roten eigenen GPS-Marker.
Der pulsierende Kreis bei +0x640 (GradientCircle) wird absichtlich noch NICHT veraendert.

Test:
1. alte Version ersetzen
2. SCUM komplett schliessen
3. ueber Launcher starten
4. -nobattleye
5. einloggen/spawnen
6. Karte oeffnen

Erwartetes Ergebnis:
roter Eigenmarker weg, pulsierender Kreis noch sichtbar.

Erwartetes Log:
HUD MATCH ... OFFSET=0x638
PATCH CURRENTBUILD ... verify=0x0
SUCCESS: current-build self marker hidden

Nur -nobattleye / private Testumgebung.
