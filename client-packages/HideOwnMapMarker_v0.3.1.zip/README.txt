HideOwnMapMarker v0.3.1 ALL HUDS
================================

Fix fuer den Fall, dass der erste gefundene BP_PrisonerHUD_C nicht der sichtbare Karten-HUD ist.

Neu:
- patcht ALLE passenden BP_PrisonerHUD_C Instanzen
- +0x638 -> T_player_marker_smaller
- +0x640 -> GradientCircle
- wiederholt den Scan alle 5 Sekunden
- patcht dadurch auch spaeter neu erzeugte HUD-Instanzen

Nur -nobattleye / private Testumgebung.
