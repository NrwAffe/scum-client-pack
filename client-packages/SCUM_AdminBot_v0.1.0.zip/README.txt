SCUM AdminBot v0.1.0 PROBE
===========================

Ziel dieser Version
-------------------
Noch KEINE Spieler automatisch kicken.

Der Bot testet zuerst den kritischen Datenpfad:
1. SCUM Admin-Client muss bereits auf deinem Server eingeloggt sein.
2. Bot aktiviert das SCUM-Fenster.
3. Bot oeffnet mit T den Chat/Command-Eingang.
4. Bot sendet #listPlayers.
5. Bot merkt sich die aktuelle Groesse von:
   %LOCALAPPDATA%\SCUM\Saved\Logs\SCUM.log
6. Nach dem Command wird nur der neu hinzugekommene Logteil gespeichert.
7. Darin werden SteamID64-Werte gesucht.

Dateien nach Test:
- AdminBot.log
- captures\capture_YYYYMMDD_HHMMSS.txt

Warum erst Probe?
-----------------
GPORTAL bestaetigt:
  #listPlayers liefert Steam64ID, Steamname, Charaktername.
  #kick <SteamID> kickt einen Spieler.

Was nicht sauber dokumentiert ist:
Ob die Ausgabe von #listPlayers auch in SCUM.log geschrieben wird.

Genau das testen wir mit diesem Paket, bevor Auto-Kicks aktiviert werden.

Voraussetzungen
---------------
- separater Steam/SCUM Account fuer den Bot empfohlen
- dessen SteamID bei GPORTAL unter Admin Access / AdminUsers.ini eintragen
- Server danach neu starten
- Bot-Client mit deinem SCUM Server verbinden
- SCUM im Vordergrund bzw. normal laufend
- Standard Chat-Key T

Test
----
1. Admin-Bot-Account auf dem Server einloggen.
2. START-ADMINBOT.bat starten.
3. Nichts im SCUM-Fenster tippen waehrend der Probe.
4. 1-2 Probe-Zyklen abwarten.
5. AdminBot.log und den neuesten captures\capture_*.txt hochladen.

Naechster Schritt
-----------------
Wenn #listPlayers im Log sichtbar ist:
- Parser fuer echte Player-Zeilen
- LauncherAuth-Abfrage pro SteamID
- Grace-Period
- #kick <SteamID> fuer nicht autorisierte Spieler
- Schutzliste fuer Bot-/Owner-SteamID

Wenn die Ausgabe NICHT im Log landet:
bauen wir als naechstes einen anderen Rueckkanal fuer die Admin-UI-Ausgabe.
