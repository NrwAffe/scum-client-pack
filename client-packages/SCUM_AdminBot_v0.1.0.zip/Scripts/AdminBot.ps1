﻿$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$ConfigPath = Join-Path $Root "Config\config.json"
$BotLog = Join-Path $Root "AdminBot.log"

function Log([string]$s) {
    Add-Content -LiteralPath $BotLog -Value ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss.fff"), $s) -Encoding UTF8
}

function Get-ScumLogPath {
    $p = Join-Path $env:LOCALAPPDATA "SCUM\Saved\Logs\SCUM.log"
    if(Test-Path -LiteralPath $p) { return $p }
    return $null
}

function Get-ScumProcess {
    $p = Get-Process -Name SCUM -ErrorAction SilentlyContinue | Select-Object -First 1
    return $p
}

function Send-ScumCommand([System.Diagnostics.Process]$Process, [string]$Command) {
    $ws = New-Object -ComObject WScript.Shell

    if(-not $ws.AppActivate($Process.Id)) {
        Log "COMMAND FAIL: SCUM window could not be activated PID=$($Process.Id)"
        return $false
    }

    Start-Sleep -Milliseconds 250

    # Default SCUM chat/command key.
    $ws.SendKeys("t")
    Start-Sleep -Milliseconds 300

    # Admin commands start with #. SendKeys needs literal typing, so type char-by-char.
    foreach($ch in $Command.ToCharArray()) {
        switch($ch) {
            "+" { $ws.SendKeys("{+}") }
            "^" { $ws.SendKeys("{^}") }
            "%" { $ws.SendKeys("{%}") }
            "~" { $ws.SendKeys("{~}") }
            "(" { $ws.SendKeys("{(}") }
            ")" { $ws.SendKeys("{)}") }
            "{" { $ws.SendKeys("{{}") }
            "}" { $ws.SendKeys("{}}") }
            default { $ws.SendKeys([string]$ch) }
        }
        Start-Sleep -Milliseconds 8
    }

    Start-Sleep -Milliseconds 150
    $ws.SendKeys("{ENTER}")
    Log "COMMAND SENT: $Command"
    return $true
}

function Read-NewLogBytes([string]$Path, [long]$StartOffset) {
    if(-not (Test-Path -LiteralPath $Path)) { return "" }

    $fs = [System.IO.File]::Open($Path,
        [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read,
        [System.IO.FileShare]::ReadWrite)

    try {
        if($StartOffset -gt $fs.Length) { $StartOffset = 0 }
        $null = $fs.Seek($StartOffset, [System.IO.SeekOrigin]::Begin)
        $remaining = $fs.Length - $StartOffset
        if($remaining -le 0) { return "" }

        $buf = New-Object byte[] $remaining
        $read = $fs.Read($buf,0,$buf.Length)
        return [Text.Encoding]::UTF8.GetString($buf,0,$read)
    }
    finally {
        $fs.Dispose()
    }
}

function Get-SteamIdsFromText([string]$Text) {
    if([string]::IsNullOrWhiteSpace($Text)) { return @() }

    $ids = [regex]::Matches($Text, '(?<!\d)7656119\d{10}(?!\d)') |
        ForEach-Object { $_.Value } |
        Sort-Object -Unique

    return @($ids)
}

if(-not (Test-Path -LiteralPath $ConfigPath)) {
    throw "Missing config: $ConfigPath"
}
$cfg = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json

@"
============================================================
SCUM AdminBot v0.1.0 PROBE
============================================================
Purpose:
  1. Send #listPlayers through the admin SCUM client.
  2. Capture the SCUM.log delta after the command.
  3. Detect SteamID64 candidates.
NO AUTO-KICK IN THIS VERSION.
============================================================
"@ | Set-Content -LiteralPath $BotLog -Encoding UTF8

Log "Bot starting"
Log "probeIntervalSeconds=$($cfg.probeIntervalSeconds) captureSeconds=$($cfg.captureSeconds)"
Log "kickEnabled=False (hardcoded probe safety)"

$lastPid = 0

while($true) {
    try {
        $p = Get-ScumProcess
        if(-not $p) {
            if($lastPid -ne 0) {
                Log "SCUM exited"
                $lastPid = 0
            }
            Start-Sleep -Seconds 2
            continue
        }

        if($lastPid -ne $p.Id) {
            $lastPid = $p.Id
            Log "SCUM found PID=$($p.Id)"
        }

        $scumLog = Get-ScumLogPath
        if(-not $scumLog) {
            Log "SCUM.log not found yet"
            Start-Sleep -Seconds 3
            continue
        }

        $before = (Get-Item -LiteralPath $scumLog).Length
        Log "PROBE start logOffset=$before path=$scumLog"

        $ok = Send-ScumCommand -Process $p -Command "#listPlayers"
        if(-not $ok) {
            Start-Sleep -Seconds ([int]$cfg.probeIntervalSeconds)
            continue
        }

        Start-Sleep -Seconds ([int]$cfg.captureSeconds)

        $delta = Read-NewLogBytes -Path $scumLog -StartOffset $before
        $ids = Get-SteamIdsFromText -Text $delta

        Log "PROBE deltaChars=$($delta.Length) steamIdCandidates=$($ids.Count)"

        if($ids.Count -gt 0) {
            foreach($id in $ids) {
                Log "STEAMID CANDIDATE $id"
            }
        } else {
            Log "NO SteamID64 found in SCUM.log delta"
        }

        # Store exact post-command log delta for inspection.
        $capture = Join-Path $Root ("captures\capture_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
        New-Item -ItemType Directory -Force -Path (Split-Path $capture -Parent) | Out-Null
        Set-Content -LiteralPath $capture -Value $delta -Encoding UTF8
        Log "CAPTURE saved $capture"

        Start-Sleep -Seconds ([int]$cfg.probeIntervalSeconds)
    }
    catch {
        Log "ERROR $($_.Exception.ToString())"
        Start-Sleep -Seconds 5
    }
}
