VoiceRadiusClient v0.2.1

Fixes:
- wartet auf SCUM statt sich vorzeitig zu beenden
- Overlay wird automatisch sichtbar, sobald SCUM laeuft
- ^ wird primaer ueber den physischen ScanCode 41 erkannt
- zusaetzlich VK 192/220/226 als Layout-Fallback
- F9 bleibt Test-Fallback

^ wechselt:
Whisper 3m -> Normal 15m -> Shout 40m -> ...

Beim Wechsel sendet der Helper weiterhin automatisch !vw / !vn / !vs.
