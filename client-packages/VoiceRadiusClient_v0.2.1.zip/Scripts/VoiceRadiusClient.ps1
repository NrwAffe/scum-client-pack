﻿param([switch]$Debug)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigFile = Join-Path $Root "Config\config.json"
$LogFile = Join-Path $Root "VoiceRadiusClient.log"

function Log([string]$m) {
    $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $m
    Add-Content -LiteralPath $LogFile -Value $line
    if($Debug){ Write-Host $line }
}

$config = Get-Content -LiteralPath $ConfigFile -Raw | ConvertFrom-Json

$src = @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public static class VRKeys
{
    public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
    public const int WH_KEYBOARD_LL = 13;
    public const int WM_KEYDOWN = 0x0100;
    public const int WM_SYSKEYDOWN = 0x0104;

    [StructLayout(LayoutKind.Sequential)]
    public struct KBDLLHOOKSTRUCT {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [DllImport("user32.dll")] public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);
    [DllImport("user32.dll")] public static extern bool UnhookWindowsHookEx(IntPtr hhk);
    [DllImport("user32.dll")] public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("kernel32.dll", CharSet=CharSet.Auto, SetLastError=true)] public static extern IntPtr GetModuleHandle(string lpModuleName);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

    public static bool IsScumForeground()
    {
        IntPtr hwnd = GetForegroundWindow();
        if(hwnd == IntPtr.Zero) return false;
        uint pid;
        GetWindowThreadProcessId(hwnd, out pid);
        try {
            Process p = Process.GetProcessById((int)pid);
            return String.Equals(p.ProcessName, "SCUM", StringComparison.OrdinalIgnoreCase);
        } catch { return false; }
    }
}
'@
Add-Type -TypeDefinition $src -Language CSharp

$win = @'
using System;
using System.Runtime.InteropServices;
public static class VRWindow {
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr hWnd, int nIndex);
    [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
}
'@
Add-Type -TypeDefinition $win -Language CSharp

$script:modes = @("whisper","normal","shout")
$script:mode = [string]$config.defaultMode
if($script:modes -notcontains $script:mode.ToLowerInvariant()){ $script:mode = "normal" }
$script:sending = $false
$script:lastToggle = [DateTime]::MinValue
$script:seenScum = $false

function Info([string]$mode) {
    switch($mode.ToLowerInvariant()) {
        "whisper" { [pscustomobject]@{Label="WHISPER";Meters=[int]$config.radiiMeters.whisper;Diameter=[int]$config.ringPixels.whisper;Command=[string]$config.commands.whisper} }
        "shout"   { [pscustomobject]@{Label="SHOUT";Meters=[int]$config.radiiMeters.shout;Diameter=[int]$config.ringPixels.shout;Command=[string]$config.commands.shout} }
        default   { [pscustomobject]@{Label="NORMAL";Meters=[int]$config.radiiMeters.normal;Diameter=[int]$config.ringPixels.normal;Command=[string]$config.commands.normal} }
    }
}

function Send-ServerCommand([string]$command) {
    if(-not [VRKeys]::IsScumForeground()) { Log "SCUM nicht im Vordergrund; Command nicht gesendet."; return }

    try {
        $script:sending = $true
        [Windows.Forms.SendKeys]::SendWait("{ENTER}")
        Start-Sleep -Milliseconds ([int]$config.chat.openDelayMs)

        $esc = $command.Replace("{","{{}").Replace("}","{}}").Replace("+","{+}").Replace("^","{^}").Replace("%","{%}").Replace("~","{~}")
        [Windows.Forms.SendKeys]::SendWait($esc)
        Start-Sleep -Milliseconds ([int]$config.chat.typeDelayMs)
        [Windows.Forms.SendKeys]::SendWait("{ENTER}")
        Log "Serverbefehl: $command"
    } catch {
        Log "Command-Fehler: $($_.Exception.Message)"
    } finally {
        Start-Sleep -Milliseconds 120
        $script:sending = $false
    }
}

function Set-Mode([string]$m) {
    $script:mode = $m
    $i = Info $m
    Log "MODE -> $($i.Label) / $($i.Meters)m"
    $form.Invalidate()
    if($config.sendServerCommand -eq $true){ Send-ServerCommand $i.Command }
}

function Next-Mode {
    $idx = [Array]::IndexOf($script:modes,$script:mode.ToLowerInvariant())
    if($idx -lt 0){ $idx = 1 }
    Set-Mode $script:modes[(($idx+1) % $script:modes.Count)]
}

$form = New-Object Windows.Forms.Form
$form.FormBorderStyle = "None"
$form.ShowInTaskbar = $false
$form.TopMost = $true
$form.BackColor = [Drawing.Color]::Magenta
$form.TransparencyKey = [Drawing.Color]::Magenta
$form.StartPosition = "Manual"
$form.Width = 480
$form.Height = 480

$screen = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Left = [Math]::Max(0,$screen.Right-$form.Width-[int]$config.marginRight)
$form.Top = [Math]::Max(0,$screen.Bottom-$form.Height-[int]$config.marginBottom)

$GWL_EXSTYLE=-20; $WS_EX_LAYERED=0x80000; $WS_EX_TRANSPARENT=0x20; $WS_EX_TOOLWINDOW=0x80
$form.Add_Shown({
    $s=[VRWindow]::GetWindowLong($form.Handle,$GWL_EXSTYLE)
    [VRWindow]::SetWindowLong($form.Handle,$GWL_EXSTYLE,$s -bor $WS_EX_LAYERED -bor $WS_EX_TRANSPARENT -bor $WS_EX_TOOLWINDOW)|Out-Null
})

$form.Add_Paint({
    param($sender,$e)
    $i = Info $script:mode
    $g=$e.Graphics
    $g.SmoothingMode=[Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $cx=[int]($form.ClientSize.Width/2); $cy=[int]($form.ClientSize.Height/2)
    $d=[int]$i.Diameter
    $x=$cx-[int]($d/2); $y=$cy-[int]($d/2)

    $pen=New-Object Drawing.Pen([Drawing.Color]::FromArgb(235,255,255,255),4)
    $pen.DashStyle=[Drawing.Drawing2D.DashStyle]::Dash
    $g.DrawEllipse($pen,$x,$y,$d,$d); $pen.Dispose()

    $fill=New-Object Drawing.SolidBrush([Drawing.Color]::FromArgb(175,0,0,0))
    $g.FillRectangle($fill,(New-Object Drawing.RectangleF(92,190,296,94))); $fill.Dispose()

    $font1=New-Object Drawing.Font("Segoe UI",20,[Drawing.FontStyle]::Bold)
    $font2=New-Object Drawing.Font("Segoe UI",10)
    $brush=New-Object Drawing.SolidBrush([Drawing.Color]::White)
    $t1="{0} | {1} m" -f $i.Label,$i.Meters
    $s1=$g.MeasureString($t1,$font1); $g.DrawString($t1,$font1,$brush,$cx-$s1.Width/2,198)
    $t2="^ = Reichweite wechseln"
    $s2=$g.MeasureString($t2,$font2); $g.DrawString($t2,$font2,$brush,$cx-$s2.Width/2,246)
    $brush.Dispose(); $font1.Dispose(); $font2.Dispose()
})

$proc = [VRKeys+LowLevelKeyboardProc]{
    param($nCode,$wParam,$lParam)

    if($nCode -ge 0 -and -not $script:sending -and (($wParam.ToInt32() -eq [VRKeys]::WM_KEYDOWN) -or ($wParam.ToInt32() -eq [VRKeys]::WM_SYSKEYDOWN))) {
        if([VRKeys]::IsScumForeground()) {
            $k=[Runtime.InteropServices.Marshal]::PtrToStructure($lParam,[type][VRKeys+KBDLLHOOKSTRUCT])
            $vk=[int]$k.vkCode
            $sc=[int]$k.scanCode

            # German ^ key is the physical key left of "1".
            # Common scan code = 41 (0x29). Also accept common OEM virtual keys.
            $cycle = ($sc -eq [int]$config.cycleScanCode) -or ($config.acceptedVirtualKeys -contains $vk)
            if($config.fallbackF9 -eq $true -and $vk -eq [int][Windows.Forms.Keys]::F9){ $cycle=$true }

            if($cycle) {
                $now=Get-Date
                if(($now-$script:lastToggle).TotalMilliseconds -ge [int]$config.debounceMs) {
                    $script:lastToggle=$now
                    Log "Cycle key erkannt: VK=$vk ScanCode=$sc"
                    Next-Mode
                }
            }
        }
    }
    return [VRKeys]::CallNextHookEx([IntPtr]::Zero,$nCode,$wParam,$lParam)
}

$module=[Diagnostics.Process]::GetCurrentProcess().MainModule
$hook=[VRKeys]::SetWindowsHookEx([VRKeys]::WH_KEYBOARD_LL,$proc,[VRKeys]::GetModuleHandle($module.ModuleName),0)
if($hook -eq [IntPtr]::Zero){ throw "Keyboard Hook konnte nicht gesetzt werden." }

Log "VoiceRadiusClient v0.2.1 gestartet."
Log "Wartet auf SCUM; beendet sich NICHT mehr vorzeitig."
Log "^: ScanCode 41 + OEM VK-Fallback; F9 bleibt Test-Fallback."

$timer=New-Object Windows.Forms.Timer
$timer.Interval=750
$timer.Add_Tick({
    $scum=Get-Process -Name SCUM -ErrorAction SilentlyContinue | Select-Object -First 1
    if($scum) {
        $script:seenScum=$true
        if(-not $form.Visible){ $form.Show(); Log "SCUM erkannt -> Overlay sichtbar." }
    } else {
        if($form.Visible){ $form.Hide() }
        if($script:seenScum -and $config.exitAfterScumCloses -eq $true) {
            Log "SCUM beendet -> VoiceRadiusClient beendet."
            $timer.Stop(); $form.Close()
        }
    }
})
$timer.Start()

# Start hidden; timer shows once SCUM exists.
$form.Opacity = 1
$form.Hide()

try { [void]$form.ShowDialog() }
finally {
    if($hook -ne [IntPtr]::Zero){ [VRKeys]::UnhookWindowsHookEx($hook)|Out-Null }
}
